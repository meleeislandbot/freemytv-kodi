"""Free My TV for Kodi: RunScript(script.freemytv,<what>[,<argument>]).

    search,<collection id>   the search screen (the month's most watched before typing)
    series,<item id>         a series' page
    title,<item id>          a movie's page (its cast, More like this)
    settings                 Free My TV's settings (the tabs)
    refresh                  the tabs' lists again, now (the refresh button; something changed on the server)
    filters[,<slot>]         the filters screen (the funnel; OK on a master tab opens it on that kind)
    later,<item id>          into Watch Later or out of it (JellyCon's menu, hold OK)
    actions,<item id>        a poster's quick actions (hold OK: JellyCon's menu sends them here first)
    inside,<collection id>   a kind of shorts' titles in Home's grid (OK on one in the Cortos tab)
    audio, version           the player's buttons: the audio track, the version (tracks.py)
"""
import os
import sys

import xbmcaddon

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

import later  # noqa: E402
import search  # noqa: E402
import series  # noqa: E402
import settings  # noqa: E402

PATH = xbmcaddon.Addon().getAddonInfo('path')
what = sys.argv[1] if len(sys.argv) > 1 else 'search'
argument = sys.argv[2] if len(sys.argv) > 2 else ''
if what == 'series' and argument:
    series.show(PATH, argument)
elif what == 'title' and argument:
    import title
    title.show(PATH, argument, title.tab_name())
elif what == 'settings':
    settings.show(PATH)
elif what == 'later' and argument:
    import jellyfin
    later.toggle(argument, jellyfin.call('/Users/{user}/Items/' + argument).get('Name', ''))
elif what == 'actions' and argument:
    import actions
    actions.show(PATH, argument)
elif what == 'inside' and argument:
    settings.inside(argument)
elif what == 'filters':
    import filters
    filters.show(PATH, argument)
elif what in ('audio', 'version'):   # the player's buttons
    import tracks
    getattr(tracks, what)()
elif what == 'refresh':   # Home's pill says it's updating meanwhile
    with settings.updating():
        later.refresh()
        settings.publish()
else:
    search.show(PATH, argument)
