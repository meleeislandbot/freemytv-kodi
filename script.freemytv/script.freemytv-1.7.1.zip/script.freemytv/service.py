"""Runs while Kodi does: Watch Later's marks every few minutes (the TV may add titles too), and the home screen's tabs
from the settings (settings.publish), once at start and whenever they change, and the master collections' ids
(filters.remember), so the filters don't wait for the server; and where Home's panel puts the facts (panel.watch).
«¿Quién está viendo?» (profiles.py) at start and when the box wakes, with two profiles or more; another profile's tabs
and lists as soon as JellyCon's user changes (a new one's from the box's, without what it can't see).
JellyCon's changes go in at start and every few minutes (jellycon_fixes); a fresh install gets its first tabs once
JellyCon is signed in (settings.defaults).
"""
import os
import sys

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

import first  # noqa: E402
import panel  # noqa: E402
import profiles  # noqa: E402
import settings  # noqa: E402

# The tabs first: at start ten add-ons load Python at once and take turns, so an import like urllib.request (later's,
# through jellyfin) takes 2 s there, and the grid can't ask for its list until the tabs are out. The first tab shows
# the copy of its last list (first.py) while JellyCon is asked for it behind.
class Monitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        if method == 'System.OnWake' and profiles.due():   # who's watching now?
            xbmc.executebuiltin('RunScript(script.freemytv,profiles)')
        elif method == 'Player.OnStop':   # Continue Watching, Next Up and the played title's marks, once JellyCon told
            __import__('threading').Timer(3, after_stop).start()   # the server
            # «¿Qué te pareció?» once JellyCon has told the server it was watched
            __import__('threading').Timer(6, xbmc.executebuiltin, ['RunScript(script.freemytv,after_watching)']).start()


def after_stop():
    """What playing changed, from the server: Continue Watching, Next Up and the tabs holding what was played or its
    series. Only those: Kodi's own reload of every grid on play and stop is off (install.py's TAB_GRID sortby)."""
    played = xbmc.getInfoLabel('Window(home).Property(plugin.video.jellycon-currently_playing_id)')
    shown = {played} if played else set()
    if played:
        try:
            shown.add(__import__('jellyfin').call('/Users/{user}/Items/%s?EnableImages=false&EnableUserData=false'
                                                  % played).get('SeriesId') or played)
        except Exception as e:   # the server away: the episode's own tabs only
            xbmc.log('Free My TV, after playing: %s' % e, xbmc.LOGWARNING)
    settings.reload_tabs(settings.holding(shown, ('resume', 'nextup')), fetch=True)


monitor = Monitor()
# Where Home's panel puts the facts, first: until it has, they could lie over a long title
__import__('threading').Thread(target=panel.watch, args=(monitor,), daemon=True).start()
address = settings.first_address()
if address and first.key() == address:
    settings.publish(copy=address)
    first.shown(monitor)
settings.publish()


def fresh():
    """A fresh install's first tabs (settings.defaults), once JellyCon is signed in: tried every few seconds till then."""
    while True:
        try:
            settings.save(settings.defaults())
            break
        except Exception:   # not signed in yet, or the server away
            if monitor.waitForAbort(10):
                return
    settings.publish()


if not settings.saved():
    __import__('threading').Thread(target=fresh, daemon=True).start()


def switched():
    """Another profile: its tabs (its own, else the box's first ones), its Watch Later marks, its lists."""
    xbmc.executebuiltin('ClearProperty(fmt_inside,home)')
    with settings.updating():
        if not settings.saved():
            fresh()
        settings.adopt()   # a new profile: the box's tabs it can see
        settings.publish()   # first: that user's lists from JellyCon's cache (asked again only when 4 h old)
        __import__('later').refresh()   # then the Watch Later marks (a question to the server)
        if __import__('popular').refresh(xbmc.getInfoLabel('Window(home).Property(fmt_popular)')):
            settings.publish()   # their month's most watched in Trakt's order (a child's: the children's)
        if __import__('filters').remember():
            settings.publish()   # their playlists in the Colecciones tab


__import__('threading').Thread(target=profiles.watch, args=(monitor, switched), daemon=True).start()
__import__('threading').Thread(target=__import__('progress').watch, args=(monitor,), daemon=True).start()   # the tabs' loading
if profiles.due():
    xbmc.executebuiltin('RunScript(script.freemytv,profiles)')
import jellycon_fixes  # noqa: E402

jellycon_fixes.in_kodi()
if settings.adopt():   # a new profile in use since the last start
    settings.publish()
import later  # noqa: E402

import filters  # noqa: E402

if address:
    first.keep(monitor, address)
if filters.remember():
    settings.publish()   # the Cortos tab's kinds or the Colecciones tab's first level found or changed
try:   # JellyCon's image cache on the screensaver off in Kodi's memory too: install.py's edit of its file holds only until
    # JellyCon saves its settings. It asked the server for the whole library each time and ran it out of memory.
    __import__('xbmcaddon').Addon('plugin.video.jellycon').setSetting('cacheImagesOnScreenSaver', 'false')
except RuntimeError:   # no JellyCon
    pass
import popular  # noqa: E402
import tracks  # noqa: E402

watcher = tracks.Watcher()   # the player's version button (kept: Kodi calls it while it lives)

top = xbmc.getInfoLabel('Window(home).Property(fmt_popular)')
if popular.refresh(top):
    settings.publish()   # the month's most watched in Trakt's order (yesterday's until now)
while not monitor.abortRequested():
    jellycon_fixes.in_kodi()   # back in after JellyCon updates itself
    later.refresh()
    if xbmc.getInfoLabel('Window(home).Property(fmt_tabs_day)') != __import__('time').strftime('%Y-%m-%d'):
        with settings.updating():
            popular.refresh(xbmc.getInfoLabel('Window(home).Property(fmt_popular)'))
            filters.refresh_saved()   # the saved filters' tabs: today's titles
            filters.remember()
            settings.publish(fresh=True)   # a new day: New Releases up to today, the most watched in today's order
    elif not xbmc.getInfoLabel('Window(home).Property(fmt_masters)') and filters.remember():
        settings.publish()   # the server too slow at start
    top = xbmc.getInfoLabel('Window(home).Property(fmt_popular)')
    if top and popular.stale(top):   # the TV changed the month's most watched: in Trakt's order again
        with settings.updating():
            if popular.refresh(top, force=True):
                settings.publish()
    if monitor.waitForAbort(300):
        break
