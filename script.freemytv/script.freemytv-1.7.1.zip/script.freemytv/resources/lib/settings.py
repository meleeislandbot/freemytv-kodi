"""Free My TV's settings on Kodi (script-freemytv-settings.xml), as the TV's: the home screen's tabs (add, move,
remove: from Jellyfin's libraries, collections and playlists), next to Kodi's sections and power as tiles. The tabs
live in addon_data/script.freemytv/tabs.json ([{"name", "what"}]: kodi/install.py writes the first ones from
config.properties on the Ugoos, the service the defaults on a fresh install)
and reach the skin as Window(home) properties (publish): fmt_tab<N>_name, and per order (own, date, rating) its
address, its button text and the next order.
"""
import json
import os
import time
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcvfs

import who

HOME = xbmcgui.Window(10000)
SLOTS = 12
FILE = 'special://profile/addon_data/script.freemytv/tabs.json'
KINDS = 'special://profile/addon_data/script.freemytv/kinds.json'   # the Cortos tab's kinds (filters.remember)
FIELDS = ('&IsVirtualUnAired=false&IsMissing=false&EnableTotalRecordCount=false&Fields=DateCreated,EpisodeCount,SeasonCount,Path,Genres,Studios,'
          'Etag,SortName,RecursiveItemCount,ChildCount,ProductionLocations,CriticRating,OfficialRating,CommunityRating,'
          'PremiereDate,ProductionYear,Status,Tags,MediaStreams,Overview&format=json')
DATE = '&SortBy=PremiereDate,SortName&SortOrder=Descending'
RATING = '&SortBy=CommunityRating,PremiereDate&SortOrder=Descending'
LABELS = {'own_resume': 'Ordenados por último visto', 'own_playlist': 'Ordenados por fecha añadida',
          'own_top': 'Ordenados por más vistos', 'own_shorts': 'Series primero, luego por puntuación',
          'own_kinds': 'Por tipos', 'own_filter': 'En el orden de los filtros', 'own_names': 'Por nombre',
          'date': 'Ordenados por lanzamiento', 'rating': 'Ordenados por puntuación'}
ROWS, TILES = 700, 702   # the tabs (and add); Kodi's sections (written in the window, they open by themselves)


def load(path=''):
    """The tabs of the profile in use (its own, else the box's first ones), or of that file."""
    try:
        with open(xbmcvfs.translatePath(path or who.readable(FILE)), encoding='utf-8') as f:
            return [t for t in json.load(f) if t.get('name') and t.get('what')]
    except (OSError, ValueError):
        return []


def saved():
    """False on a fresh install (from the repository): no tabs yet, not even an empty list."""
    return os.path.exists(xbmcvfs.translatePath(who.readable(FILE)))


def defaults():
    """A fresh install's tabs, as the TV's: the server's shared collections, found by name (the month's most watched,
    the master collections), with New Releases and Continue Watching among them. Playlists are each user's own, so
    none; without the master collections, every movie and every show. Raises while JellyCon isn't signed in."""
    import jellyfin
    found = {o.get('Name', '').strip().lower(): o['Id'] for o in jellyfin.call(
        '/Users/{user}/Items?IncludeItemTypes=BoxSet&Recursive=true&EnableImages=false&EnableUserData=false').get('Items', [])}
    masters = [{'name': n, 'what': found[n.lower()]} for n in ('Películas', 'Series') if n.lower() in found] or [
        {'name': 'Películas', 'what': 'movies'}, {'name': 'Series', 'what': 'series'}]
    top_id = found.get('lo más visto del mes') or found.get(jellyfin.KIDS_POPULAR)   # (a child's only sees the children's)
    top = [{'name': 'Lo más visto del mes', 'what': 'top:' + top_id}] if top_id else []
    return (top + [{'name': 'Novedades', 'what': 'latest'}] + masters + [{'name': 'Seguir viendo', 'what': 'resume'}]
            + [{'name': n, 'what': found[n.lower()]} for n in ('Documentales', 'Cortos') if n.lower() in found])


def adapted():
    """A new profile's first tabs: the box's (tabs.json), each one that user can't call theirs (another's playlist, a
    collection not shared with them) becoming theirs of the same name and kind (their own playlist «Películas» for
    Eden's); Ver más tarde theirs, made empty if need be; one with no such list left out. With none of the lists
    left, defaults()."""
    import re
    import jellyfin
    hexid = re.compile('[0-9a-f]{32}')
    theirs = jellyfin.call('/Users/{user}/Items?IncludeItemTypes=BoxSet,Playlist&Recursive=true&EnableImages=false'
                           '&EnableUserData=false').get('Items', [])
    seen = {o['Id'] for o in theirs}
    mine, by_name = {}, {}
    for o in theirs:
        name = o.get('Name', '').strip().lower()
        mine.setdefault((o.get('Type'), name), o['Id'])
        by_name.setdefault(name, o['Id'])
    tabs = load(FILE)

    def key_of(what):
        return what.split(':')[1] if what.startswith(('top:', 'kinds:', 'shorts:', 'playlist:')) else what
    missing = [key_of(t['what']) for t in tabs if hexid.fullmatch(key_of(t['what'])) and key_of(t['what']) not in seen]
    named = {}   # what the box's lists are, by id: the server tells them by id even when they're another's
    if missing:
        for o in jellyfin.call('/Users/{user}/Items?Ids=%s&EnableImages=false&EnableUserData=false'
                               % ','.join(missing)).get('Items', []):
            named[o['Id']] = (o.get('Type'), o.get('Name', '').strip().lower())
    out, lists = [], 0
    for t in tabs:
        what, key = t['what'], key_of(t['what'])
        if not hexid.fullmatch(key) or key in seen:
            out.append(t)
            lists += bool(hexid.fullmatch(key))
            continue
        kind, name = named.get(key, (None, t['name'].strip().lower()))
        own = mine.get((kind, name)) or by_name.get(name)
        if what.startswith('top:') and jellyfin.child():   # a child's: the children's collection
            own = jellyfin.kids_popular() or None
        if own is None and name in jellyfin.LATER_NAMES:
            own = jellyfin.own_later()   # theirs, empty for now
        if own:
            out.append({'name': t['name'], 'what': what.replace(key, own)})
            lists += 1
    return out if lists else defaults()


def adopt():
    """A profile without tabs of its own gets adapted() ones, kept as its own; True when it did."""
    if (os.path.exists(xbmcvfs.translatePath(who.own(FILE)))
            or not os.path.exists(xbmcvfs.translatePath(FILE))):   # its own already, or the box has none to adapt
        return False
    try:
        save(adapted())
    except Exception as e:   # JellyCon not answering as that user yet: the box's tabs till the next try
        xbmc.log('Free My TV, a new profile\'s tabs: %s' % e, xbmc.LOGWARNING)
        return False
    xbmc.log('Free My TV: tabs of their own for %s' % who.name(), xbmc.LOGINFO)
    return True


def save(tabs):
    path = xbmcvfs.translatePath(who.own(FILE))   # each profile's own tabs (who.py)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(tabs, f, ensure_ascii=False, indent=1)


# MARK: - The tabs' addresses (what the home screen's grid asks JellyCon for)

def modes(what):
    """The tab's orders, its first the one it starts in (as on the TV: its own, if it has one, then date, rating). The
    month's most watched starts most watched first (Trakt's order, popular.py), as the TV's (Recs.toggleSort)."""
    if what in ('nextup', 'collections', 'playlists') or what.startswith('filter:'):   # the server's order only (NextUp doesn't sort;
    # a filter has its own; the collections, masters first)
        return ['own']
    if what == 'resume' or what.startswith(('playlist:', 'shorts:', 'kinds:')):
        return ['own', 'date', 'rating']
    return ['own', 'date', 'rating'] if what.startswith('top:') else ['date', 'rating']


POPULAR_KINDS = ('', 'Movie', 'Series')
KIND_NAMES = {'': 'Todo', 'Movie': 'Películas', 'Series': 'Series'}


def popular_kind():
    """What the month's most watched shows: '' all of it, 'Movie' or 'Series' (as the TV's Jellyfin.popularKind)."""
    kind = xbmc.getInfoLabel('Skin.String(fmt_popular_kind)')
    return kind if kind in POPULAR_KINDS else ''


def toggle_popular_kind():
    """OK on the month's most watched: all of it → its movies → its shows → …, kept in a skin string."""
    kind = POPULAR_KINDS[(POPULAR_KINDS.index(popular_kind()) + 1) % len(POPULAR_KINDS)]
    xbmc.executebuiltin('Skin.SetString(fmt_popular_kind,%s)' % kind if kind else 'Skin.Reset(fmt_popular_kind)', True)
    publish()
    xbmcgui.Dialog().notification('Lo más visto del mes', KIND_NAMES[kind], xbmcgui.NOTIFICATION_INFO, 2500, False)


def label(what, mode):
    if mode != 'own':
        return LABELS[mode]
    return LABELS['own_resume' if what in ('resume', 'nextup') else 'own_top' if what.startswith('top:')
                  else 'own_shorts' if what.startswith('shorts:') else 'own_kinds' if what.startswith('kinds:')
                  else 'own_filter' if what.startswith('filter:') else 'own_kinds' if what == 'collections'
                  else 'own_names' if what == 'playlists' else 'own_playlist']


def is_child():
    import jellyfin
    try:
        return jellyfin.child()
    except Exception:   # JellyCon not signed in
        return False


def kids_top():
    """A child's profile's month's most watched: the children's collection's id, '' for anyone else (kept per user)."""
    import jellyfin
    try:
        if not jellyfin.child():
            return ''
        user = jellyfin.session()[1]
    except Exception:
        return ''
    kept = HOME.getProperty('fmt_kids_top')
    if not kept.startswith(user + '|'):
        try:
            kept = '%s|%s' % (user, jellyfin.kids_popular())
        except Exception:
            return ''
        HOME.setProperty('fmt_kids_top', kept)
    return kept.split('|', 1)[1]


def tab_what(tab):
    """What the tab shows: the shorts' master collection ("Cortos", as the TV's Jellyfin.shorts) as its kinds
    ('kinds:<id>:<ids>', the collections in "Tipos - Cortos" and "Anime - Cortos", which filters.remember keeps; its
    animation by date or rating), else as 'shorts:<id>' (its animation)."""
    if tab['what'].startswith('top:') and kids_top():   # a child's: the children's collection (jellyfin.child)
        return 'top:' + kids_top()
    if tab['name'].strip().lower() not in ('cortos', 'cortometrajes'):
        return tab['what']
    kinds = short_kinds()
    return 'kinds:%s:%s' % (tab['what'], ','.join(kinds)) if kinds else 'shorts:' + tab['what']


def shown_grid():
    """Home's grid of the tab shown: each tab's is 9100 + its slot (install.py's GRID)."""
    return 9100 + int(xbmc.getInfoLabel('Window(home).Property(fmt_tab)') or 1)


@__import__('contextlib').contextmanager
def updating():
    """Home's "Actualizando las listas…" pill while the lists are worked out here (the grid's reload holds it after)."""
    HOME.setProperty('fmt_updating', 'true')
    try:
        yield
    finally:
        monitor = xbmc.Monitor()
        if xbmc.getCondVisibility('Window.IsVisible(home)') and not monitor.waitForAbort(0.5):
            for _ in range(60):   # the grid's reload of what was published, up to 15 s
                if not xbmc.getCondVisibility('Container(%d).IsUpdating' % shown_grid()) or monitor.waitForAbort(0.25):
                    break
        HOME.clearProperty('fmt_updating')


def reload_tabs(slots, fetch=False):
    """Only those tabs' grids ask again (a new reload in their addresses), not all of them as publish(fresh) does;
    fetch: JellyCon brings their lists from the server at once (jellycon_fixes' FETCH_FIX), not its cache first."""
    today, tabs = time.strftime('%Y-%m-%d'), load()[:SLOTS]
    reload = '%.3f%s' % (time.time(), '&fmt_fetch=1' if fetch else '')
    for i in slots:
        if i <= len(tabs):
            what = tab_what(tabs[i - 1])
            for m in modes(what):
                HOME.setProperty('fmt_tab%d_%s' % (i, m), path_for(what, m, today, reload))


def holding(item_ids, whats=()):
    """The tabs whose grid holds any of item_ids as loaded (their marks change), or that are one of whats."""
    out = []
    for i, t in enumerate(load()[:SLOTS], 1):
        grid = 9100 + i
        count = int(xbmc.getInfoLabel('Container(%d).NumItems' % grid) or 0)
        if (t['what'] in whats or tab_what(t) in whats or
                any(xbmc.getInfoLabel('Container(%d).ListItemAbsolute(%d).Property(id)' % (grid, n)) in item_ids
                    for n in range(count))):
            out.append(i)
    return out


def short_kinds():
    try:
        with open(xbmcvfs.translatePath(KINDS), encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def go_in(what):
    """Shows `what` in the tab's grid, a level in: Back (up) goes to the one before, at the last to the tab's own. The
    levels before are kept in fmt_inside_up, one address a line; another tab clears fmt_inside, and with it them."""
    now = HOME.getProperty('fmt_inside')
    HOME.setProperty('fmt_inside_up', HOME.getProperty('fmt_inside_up') + '\n' + now if now else '')
    HOME.setProperty('fmt_inside', path_for(what, 'own', '', str(int(time.time()))))


def up():
    """Back in the grid while it shows a level in (go_in): the level before, or the tab's own list."""
    levels = HOME.getProperty('fmt_inside_up').split('\n')
    HOME.setProperty('fmt_inside_up', '\n'.join(levels[:-1]))
    if levels[-1]:
        HOME.setProperty('fmt_inside', levels[-1])
    else:
        HOME.clearProperty('fmt_inside')


def inside(collection):
    """OK on a collection (the Colecciones tab, a kind of shorts) or a playlist (playlist:<id>): the collections in it
    by name, if it holds some (Películas › Géneros › …), else its titles (the series first, then best rated); a
    playlist's in its order."""
    if not collection.startswith('playlist:'):
        import jellyfin
        try:
            nested = jellyfin.call('/Users/{user}/Items?ParentId=%s&IncludeItemTypes=BoxSet&Limit=1&EnableImages=false'
                                   '&EnableUserData=false' % collection).get('TotalRecordCount', 0)
        except Exception as e:   # the server away: its titles, as before
            xbmc.log('Free My TV, collection: %s' % e, xbmc.LOGWARNING)
            nested = 0
        collection = ('sets:' if nested else 'inside:') + collection
    go_in(collection)


def similar(item_id):
    """More like this from the quick actions: the server's similar titles in the grid, till Back or another tab."""
    go_in('similar:' + item_id)


def first_address():
    """The first tab's address in the order it's showing, without its reload (first.json's key)."""
    tabs = load()
    if not tabs:
        return ''
    ms = modes(tab_what(tabs[0]))
    mode = xbmc.getInfoLabel('Skin.String(fmt_sort_1)')
    return path_for(tab_what(tabs[0]), mode if mode in ms else ms[0], time.strftime('%Y-%m-%d'), '')


def path_for(what, mode, today, reload):
    """JellyCon's address for a tab in an order (GET_CONTENT with sort=none keeps the server's order). Written out in
    full: Kodi doesn't fill in $INFO[] inside a property's value. A new reload makes the grid ask again."""
    order = RATING if mode == 'rating' else DATE
    if what == 'latest':
        # The last year's only: sorting the whole library by date is what the server is slowest at
        year_ago = time.strftime('%Y-%m-%d', time.localtime(time.time() - 365 * 86400))
        url = ('/Users/{userid}/items?IncludeItemTypes=Movie,Series&Recursive=true&MinPremiereDate=%s&MaxPremiereDate=%s'
               '&Limit=200%s%s' % (year_ago, today, order, '&Genres=' + quote('Animación') if is_child() else ''))   # a child's: cartoons
    elif what == 'resume':
        url = ('/Users/{userid}/Items/Resume?MediaTypes=Video&Limit=100' if mode == 'own' else
               '/Users/{userid}/items?Filters=IsResumable&Recursive=true&MediaTypes=Video&Limit=100' + order)
    elif what == 'nextup':   # each series' next episode; the half-watched ones are Continue Watching's (as Jellyfin's web)
        url = '/Shows/NextUp?UserId={userid}&EnableResumable=false&Limit=100'
    elif what.startswith('playlist:'):
        url = ('/Playlists/%s/Items?UserId={userid}' % what[9:] if mode == 'own' else
               '/Users/{userid}/items?ParentId=%s%s' % (what[9:], order))
    elif what.startswith('top:'):
        import popular
        ranked = popular.ids(what[4:]) if mode == 'own' else []
        url = ('/Users/{userid}/Items?Ids=' + ','.join(ranked) if ranked   # Jellyfin keeps the order asked for
               else '/Users/{userid}/items?ParentId=%s%s' % (what[4:], order if mode != 'own' else RATING))
        if popular_kind():   # OK on the tab: its movies or its shows only
            url += '&IncludeItemTypes=' + popular_kind()
    elif what.startswith('kinds:') and mode == 'own':   # in the order kept: by name, Anime last
        url = '/Users/{userid}/Items?Ids=' + what.split(':')[2]
    elif what in ('collections', 'playlists'):   # the master collections, or the user's playlists (filters.remember)
        url = '/Users/{userid}/Items?Ids=' + (HOME.getProperty('fmt_' + what) or '0' * 32)   # none yet: none
    elif what.startswith('sets:'):   # the collections in one, by name
        url = '/Users/{userid}/Items?ParentId=%s&IncludeItemTypes=BoxSet&SortBy=SortName&Limit=200' % what[5:]
    elif what.startswith('similar:'):
        url = '/Items/%s/Similar?UserId={userid}&Limit=40' % what[8:]
    elif what.startswith('inside:'):
        url = ('/Users/{userid}/items?ParentId=%s&Recursive=true&IncludeItemTypes=Movie,Series&Limit=200'
               '&SortBy=IsFolder,CommunityRating,PremiereDate&SortOrder=Descending' % what[7:])
    elif what.startswith(('shorts:', 'kinds:')):   # animation only, the anthology series first, then best rated
        url = ('/Users/{userid}/items?ParentId=%s&Recursive=true&IncludeItemTypes=Movie,Series&Genres=%s&Limit=200%s'
               % (what.split(':')[1], quote('Animación'), order if mode != 'own'
                  else '&SortBy=IsFolder,CommunityRating,PremiereDate&SortOrder=Descending'))
    elif what.startswith('filter:'):   # a saved filter (filters.py): its address as worked out last
        import filters
        url = filters.saved_url(what)
    elif what in ('movies', 'series'):   # the whole library of that kind (the default tabs: no ids needed)
        url = ('/Users/{userid}/items?IncludeItemTypes=%s&Recursive=true&Limit=200%s'
               % ('Movie' if what == 'movies' else 'Series', order))
    else:
        url = '/Users/{userid}/items?ParentId=%s&Recursive=true&IncludeItemTypes=Movie,Series&Limit=200%s' % (what, order)
    return ('plugin://plugin.video.jellycon/?url=' + quote(url + FIELDS, safe='/')
            + '&mode=GET_CONTENT&media_type=Playlist&sort=none&reload=' + reload)


def publish(copy='', fresh=False):
    """The tabs, as the skin reads them (again each day, for New Releases' date, and after Watch Later changes). A
    tab that changed slot starts in its own first order again. copy: the address (without its reload) of the list
    first.json holds; when it's the first tab's, the grid gets that copy (plugin.py) instead of JellyCon."""
    today, reload, user = time.strftime('%Y-%m-%d'), HOME.getProperty('fmt_reload'), who.name()
    # The same reload while nothing changed: a grid whose address is the same isn't asked again, so a publish that
    # only changed one tab (its order, the month's ranking, a tab moved) reloads that one, not all of them at once.
    # The addresses say {userid}, not who: another profile needs a new one too.
    if fresh or not reload or HOME.getProperty('fmt_reload_user') != user:
        reload = str(max(int(time.time()), int(reload or 0) + 1))   # never the last one again, even within a second
        HOME.setProperty('fmt_reload', reload)
        HOME.setProperty('fmt_reload_user', user)
    tabs = load()[:SLOTS]
    before = HOME.getProperty('fmt_tabs_key')
    if fresh:   # something changed them (watched, Watch Later, the refresh button, a new day): JellyCon asks again
        HOME.setProperty('fmt_fresh_after', reload)   # behind its cache (jellycon_fixes); else its cache under 4 h does
    key = '|'.join(tab_what(t) for t in tabs)
    # Each property waits for the GUI's next frame (some 250 of them took 3 s at start): the tabs go first, the first
    # one first so the grid can ask for it, and only what an earlier publish left behind is cleared.
    for i, t in enumerate(tabs, 1):
        what = tab_what(t)
        ms = modes(what)
        HOME.setProperty('fmt_tab%d_name' % i, t['name'])
        HOME.setProperty('fmt_tab%d_first' % i, ms[0])
        HOME.setProperty('fmt_tab%d_top' % i, '1' if what.startswith('top:') else '')
        for n, m in enumerate(ms):
            path = path_for(what, m, today, reload)
            if copy and i == 1 and path_for(what, m, today, '') == copy:
                path = 'plugin://script.freemytv/?copy=' + reload
            HOME.setProperty('fmt_tab%d_%s' % (i, m), path)
            HOME.setProperty('fmt_tab%d_next_%s' % (i, m), ms[(n + 1) % len(ms)])
            HOME.setProperty('fmt_tab%d_nextlabel_%s' % (i, m), label(what, ms[(n + 1) % len(ms)]))
    if before:
        for i in range(1, SLOTS + 1):
            kept = modes(tab_what(tabs[i - 1])) if i <= len(tabs) else []
            for m in ('own', 'date', 'rating'):
                if m not in kept:
                    for name in ('%s', 'next_%s', 'nextlabel_%s'):
                        HOME.clearProperty('fmt_tab%d_%s' % (i, name % m))
            if not kept:
                HOME.clearProperty('fmt_tab%d_name' % i)
                HOME.clearProperty('fmt_tab%d_first' % i)
                HOME.clearProperty('fmt_tab%d_top' % i)
            if before != key:
                xbmc.executebuiltin('Skin.Reset(fmt_sort_%d)' % i)
    HOME.setProperty('fmt_tabs_key', key)
    HOME.setProperty('fmt_tabs_day', today)   # last: until then Home says it's loading, not that a tab is empty
    top = next((tab_what(t)[4:] for t in tabs if t['what'].startswith('top:')), '')   # (a child's: the children's)
    HOME.setProperty('fmt_popular', top)


# MARK: - The window

def choices(present):
    """What can become a tab: the TV's own sections, then Jellyfin's libraries, collections and playlists (those not
    tabs yet), grouped as on the TV's list picker."""
    import jellyfin   # here, not at the top: the service publishes the tabs before urllib loads (slow at start)
    out = [(n, w) for n, w in (('Colecciones', 'collections'), ('Playlists', 'playlists'), ('Novedades', 'latest'),
                               ('Seguir viendo', 'resume'),
                               ('A continuación', 'nextup'),
                               ('Todas las películas', 'movies'),
                               ('Todas las series', 'series')) if w not in present]
    light = '&EnableImages=false&EnableUserData=false&Fields=SortName'   # names only: much faster
    groups = (('Biblioteca', '/Users/{user}/Views?EnableImages=false'),
              ('Colección', '/Users/{user}/Items?IncludeItemTypes=BoxSet&Recursive=true&SortBy=SortName' + light),
              ('Lista', '/Users/{user}/Items?IncludeItemTypes=Playlist&Recursive=true&SortBy=SortName' + light))
    for title, path in groups:
        for o in jellyfin.call(path).get('Items', []):
            if o.get('CollectionType') in ('boxsets', 'playlists'):
                continue   # the libraries that hold the collections and lists themselves
            name = o.get('Name', '')
            if o.get('Type') == 'Playlist':
                what = 'playlist:' + o['Id']
            elif name.strip().lower() == 'lo más visto del mes':
                what = 'top:' + o['Id']
            else:
                what = o['Id']
            if what not in present:
                out.append(('%s  ·  %s' % (title, name), what, name))
    return [(c[0], c[1], c[2] if len(c) > 2 else c[0]) for c in out]


def backdrop():
    """The focused title's backdrop on Home, blurred by Jellyfin (Kodi can't blur), for behind this window; '' if none."""
    grid = 'Container(%d).ListItem.' % shown_grid()
    item = xbmc.getInfoLabel(grid + 'Property(id)')   # read while Home is still the window on top
    if not item:
        return ''
    try:
        import jellyfin
        server = jellyfin.session()[0]
    except Exception:   # JellyCon signed out: the plain dark background
        return ''
    # A title without a backdrop (old shorts often have none: Jellyfin answers 404) gives its poster, blurred the same
    image = 'Backdrop/0' if xbmc.getInfoLabel(grid + 'Art(fanart)') else 'Primary'
    return '%s/Items/%s/Images/%s?maxWidth=960&quality=80&blur=40' % (server, item, image)


class Settings(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.fill()
        self.setFocusId(TILES)

    def fill(self, focus=0):
        tabs = load()
        rows = []
        for t in tabs:
            item = xbmcgui.ListItem(t['name'], str(len(rows) + 1))   # its place on the home screen
            item.setProperty('kind', 'tab')
            rows.append(item)
        item = xbmcgui.ListItem('Añadir pestaña…')
        item.setProperty('kind', 'add')
        rows.append(item)
        control = self.getControl(ROWS)
        control.reset()
        control.addItems(rows)
        control.selectItem(min(focus, len(rows) - 1))
        self.setProperty('count', '%d pestañas' % len(tabs))

    # OK on a tab picks it up (the TV's move mode): ↑↓ carry it, OK leaves it there, ← removes it, Back undoes.
    # Kodi moves the list's focus before onAction runs, so the tab follows the focus.
    moving = None   # (the tabs as they were, the tabs as they're being moved) while a tab is picked up

    def onAction(self, action):
        a = action.getId()
        if self.moving:
            if a in (3, 4):
                self.follow()
            elif a == 1:
                self.remove()
            elif a in (9, 10, 92):
                self.drop(self.moving[0], self.start)
            return
        if a in (9, 10, 92):
            self.close()

    def follow(self):
        tabs, rows = self.moving[1], self.getControl(ROWS)
        to = rows.getSelectedPosition()
        if to == self.at or not 0 <= to < len(tabs):
            return
        tabs.insert(to, tabs.pop(self.at))
        for i in range(min(to, self.at), max(to, self.at) + 1):
            rows.getListItem(i).setLabel(tabs[i]['name'])
        self.at = to

    def remove(self):
        tabs = self.moving[1]
        if xbmcgui.Dialog().yesno('Quitar pestaña', '¿Quitar «%s» de la portada?' % tabs[self.at]['name']):
            tabs.pop(self.at)
            self.drop(tabs, self.at)

    def drop(self, tabs, focus):
        if tabs != self.moving[0]:
            save(tabs)
            publish()
        self.moving = None
        self.clearProperty('moving')
        self.fill(focus)

    def onClick(self, control):
        if control != ROWS:
            return
        if self.moving:
            self.drop(self.moving[1], self.at)
            return
        index = self.getControl(ROWS).getSelectedPosition()
        kind = self.getControl(ROWS).getSelectedItem().getProperty('kind')
        tabs = load()
        if kind == 'tab':
            self.moving, self.at, self.start = (tabs, [dict(t) for t in tabs]), index, index
            self.getControl(ROWS).removeItem(len(tabs))   # no Add row below while one is carried
            self.getControl(ROWS).selectItem(index)   # (removing a row sends the list back to its first)
            self.setProperty('moving', 'true')
        elif kind == 'add':
            if len(tabs) >= SLOTS:
                xbmcgui.Dialog().ok('Pestañas', 'Caben %d pestañas: quita alguna primero.' % SLOTS)
                return
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            try:
                found = choices([t['what'] for t in tabs])
            except Exception as e:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmcgui.Dialog().ok('Pestañas', 'Jellyfin no responde ahora: %s' % e)
                return
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            pick = xbmcgui.Dialog().select('Añadir pestaña', [c[0] for c in found])
            if pick < 0:
                return
            tabs.append({'name': found[pick][2], 'what': found[pick][1]})
            save(tabs)
            publish()
            self.fill(len(tabs) - 1)


def show(addon_path):
    window = Settings('script-freemytv-settings.xml', addon_path, 'Default', '1080i')
    window.setProperty('backdrop', backdrop())
    window.doModal()
    del window
