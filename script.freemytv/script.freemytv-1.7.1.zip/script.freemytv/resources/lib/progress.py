"""How Home's tabs' grids are loading (each tab's is kept loaded: install.py's GRID), as the TV's (Jellyfin.progress):
the notices' pill says «Actualizando las listas…  3/11» while any is, and a tab still to come carries a dot after its
name (fmt_tab<N>_mark).
Lists JellyCon found changed behind its cache (jellycon_fixes' REFRESH_FIX) reload here, when no grid is loading and
none has changed for 2 s: only those tabs' grids; Kodi's Container.Refresh (all of them) only for a list that's no
tab's (More like this, a kind of shorts).
"""
import time
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
GRID, SLOTS = 9100, 12


def server_url(address):
    """The server's address a JellyCon listing asks for (its url=), as written in a tab's (settings.path_for)."""
    return parse_qs(urlsplit(address).query).get('url', [''])[0]


def changed_tabs(addresses, tabs):
    """The tabs whose list is one of these listings' addresses, and whether any is no tab's."""
    shown = {i: {server_url(HOME.getProperty('fmt_tab%d_%s' % (i, m))) for m in ('own', 'date', 'rating')} for i in tabs}
    slots, others = set(), False
    for url in {server_url(a) for a in addresses}:   # '' for a listing whose address wasn't kept
        found = {i for i, urls in shown.items() if url and url in urls}
        slots |= found
        others = others or not found
    return sorted(slots), others


def watch(monitor):
    marks = {}
    while not monitor.waitForAbort(0.4):
        if not xbmc.getCondVisibility('Window.IsVisible(home)'):
            continue
        tabs = [i for i in range(1, SLOTS + 1) if HOME.getProperty('fmt_tab%d_name' % i)]
        loading = {i for i in tabs if xbmc.getCondVisibility('Container(%d).IsUpdating' % (GRID + i))}
        due = HOME.getProperty('fmt_refresh_due')
        if due and not loading and time.time() - float(due) > 2:
            changed = HOME.getProperty('fmt_changed')
            HOME.clearProperty('fmt_refresh_due')
            HOME.clearProperty('fmt_changed')
            slots, others = changed_tabs(changed.split('\n')[1:], tabs)   # each one put "\n<address>"
            if slots:
                __import__('settings').reload_tabs(slots)   # their lists from JellyCon's cache, just saved
            if others:
                xbmc.executebuiltin('Container.Refresh')
        HOME.setProperty('fmt_progress', '%d/%d' % (len(tabs) - len(loading), len(tabs)) if loading else '')
        for i in tabs:
            mark = '•' if i in loading else ''
            if marks.get(i) != mark:   # each property set waits for the GUI's next frame: only changes
                HOME.setProperty('fmt_tab%d_mark' % i, mark)
                marks[i] = mark
