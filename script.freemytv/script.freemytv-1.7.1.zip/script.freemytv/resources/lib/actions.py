"""A poster's quick actions (hold OK, as the TV's QuickActivity): play it, Watch Later, your rating in Trakt, watched,
not interested, More like this, an episode's series and, last, JellyCon's own menu. Trakt's go through palantir-cine
(cine.py), which knows each profile's Trakt: without it they don't show. JellyCon's menu replaces Kodi's context menu; the patch in
jellycon_fixes.py sends it here first while Home is open, and «Más opciones» opens JellyCon's after all.
"""
import xbmc
import xbmcgui

import cine
import held
import jellyfin
import later
import settings
import who

HOME = xbmcgui.Window(10000)
GROUP, PANEL, ROWS = 98, 99, 100
ROW_H, TOP, BOTTOM = 76, 136, 24
BACK = (9, 10, 92)


def facts(o):
    """What it is · year · length · genres, as the TV's panel."""
    kind = o.get('Type')
    parts = ['Serie' if kind == 'Series' else 'Capítulo' if kind == 'Episode' else 'Película']
    if o.get('ProductionYear'):
        parts.append(str(o['ProductionYear']))
    minutes = int(o.get('RunTimeTicks') or 0) // 600000000
    if minutes:
        parts.append('%d h %d min' % divmod(minutes, 60) if minutes >= 60 else '%d min' % minutes)
    if o.get('Genres'):
        parts.append(' / '.join(o['Genres'][:2]))
    return '  ·  '.join(parts)


def rows(o, st=None):
    """[(action, label, hint, icon)] for the title; st: its state in palantir-cine (cine.state), or None."""
    kind, played = o.get('Type'), bool(o.get('UserData', {}).get('Played'))
    st = st or {}
    out = []
    if kind in ('Movie', 'Episode'):
        out.append(('play', 'Reproducir', '', 'play.png'))
    if kind == 'Movie':
        out.append(('later', 'Quitar de Ver más tarde' if o['Id'] in later.ids() else 'Ver más tarde', '', 'plus.png'))
    elif kind == 'Series' and st.get('trakt'):   # a playlist splits a series into its episodes: Trakt's watchlist
        out.append(('later_trakt', 'Quitar de Ver más tarde' if st.get('pendiente_trakt') else 'Ver más tarde',
                    'en Trakt', 'plus.png'))
    if kind in ('Movie', 'Series') and st.get('trakt') and not st.get('infantil'):
        rated = st.get('nota')
        out.append(('rate', 'Tu nota: %d' % rated if rated else 'Valorar',
                    cine.WORDS.get(rated, '') if rated else 'en Trakt', 'star.png'))
    mark = ('Marcar como no vista' if played else 'Marcar como vista') if kind != 'Episode' else \
        ('Marcar como no visto' if played else 'Marcar como visto')
    out.append(('watched', mark, 'toda la serie' if kind == 'Series' else '', 'tick.png'))
    if kind in ('Movie', 'Series') and not played and st and not st.get('descartado'):
        out.append(('nope', 'No me interesa', 'no te lo volverá a recomendar', 'nope.png'))
    if kind in ('Movie', 'Series'):
        out.append(('similar', 'Más como esto', '', 'grid.png'))
    if kind == 'Episode' and o.get('SeriesId'):
        out.append(('series', 'Ir a la serie', 'temporadas y capítulos', 'lines.png'))
    out.append(('more', 'Más opciones', 'JellyCon', 'dots.png'))
    return out


class Actions(xbmcgui.WindowXMLDialog):
    item = None
    shown = ()
    chosen = None
    facts = None   # the line under the title: what it is (facts()), or a question
    low = False   # at the bottom of the screen (the question after watching), not in the middle

    def onInit(self):
        self.setProperty('name', self.item.get('Name', ''))
        self.setProperty('facts', self.facts or facts(self.item))
        items = []
        for _, label, hint, icon in self.shown:
            li = xbmcgui.ListItem(label, hint)
            li.setArt({'icon': 'freemytv/' + icon})
            items.append(li)
        control = self.getControl(ROWS)
        control.reset()
        control.addItems(items)
        control.setHeight(len(items) * ROW_H)
        height = TOP + len(items) * ROW_H + BOTTOM
        self.getControl(PANEL).setHeight(height)
        self.getControl(GROUP).setPosition(660, 1080 - height - 48 if self.low else (1080 - height) // 2)
        self.setFocusId(ROWS)
        held.mark()

    def onClick(self, control):
        if held.repeat():   # the OK that opened this still held: not a choice
            return
        if control == ROWS:
            self.chosen = self.shown[self.getControl(ROWS).getSelectedPosition()][0]
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


def choose(addon_path, o, shown, facts_line=None, low=False, seconds=0):
    """The action chosen among `shown` (its key), or None; with seconds, it closes by itself after them."""
    window = Actions('script-freemytv-actions.xml', addon_path, 'Default', '1080i')
    window.item, window.shown, window.facts, window.low = o, shown, facts_line, low
    timer = None
    if seconds:
        import threading
        timer = threading.Timer(seconds, window.close)
        timer.start()
    window.doModal()
    if timer:
        timer.cancel()
    chosen = window.chosen
    del window
    return chosen


def _cine(do, said):
    """Asks palantir-cine and says how it went."""
    try:
        do()
        xbmcgui.Dialog().notification('Free My TV', said, xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    except Exception as e:
        xbmc.log('Free My TV, palantir-cine: %s' % e, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Free My TV', 'No se pudo: %s' % e, xbmcgui.NOTIFICATION_WARNING, 5000)
        return False


def rate(addon_path, o, st=None, question=None, seconds=0):
    """Its rating in this profile's Trakt: Me encantó / Me gustó / No me gustó, an exact one, or none."""
    rated = (st or {}).get('nota')
    shown = [(str(n), label, '%d de 10' % n, 'star.png') for n, label in cine.QUICK]
    if not question:
        shown.append(('exact', 'Nota exacta…', 'del 1 al 10', 'dots.png'))
        if rated:
            shown.append(('0', 'Quitar mi nota', 'ahora: %d' % rated, 'trash.png'))
    chosen = choose(addon_path, o, shown, question, low=bool(question), seconds=seconds)
    if chosen == 'exact':
        chosen = choose(addon_path, o, [(str(n), '%d  ·  %s' % (n, cine.WORDS[n]), '', 'star.png')
                                        for n in range(10, 0, -1)])
    if chosen is None:
        return
    n = int(chosen)
    user = who.name()
    _cine(lambda: cine.call('valorar', usuario=user, titulo_o_id=o['Id'], nota=n),
          ('Tu nota: %d · %s' % (n, cine.WORDS[n]) if n else 'Nota quitada') + ': ' + o.get('Name', ''))


def show(addon_path, item_id):
    o = jellyfin.call('/Users/{user}/Items/%s?Fields=Genres&EnableImages=false' % item_id)
    if not o:
        return
    if o.get('Type') in ('BoxSet', 'Playlist'):   # a collection's actions would play or mark thousands: it opens
        import settings
        settings.inside(('playlist:' if o['Type'] == 'Playlist' else '') + item_id)
        return
    user = who.name()
    st = cine.state(user, item_id) if o.get('Type') in ('Movie', 'Series') else None
    chosen = choose(addon_path, o, rows(o, st))
    name = o.get('Name', '')
    if chosen == 'play':
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % jellyfin.play(item_id))   # JellyCon asks about resuming
    elif chosen == 'later':
        later.toggle(item_id, name)
    elif chosen == 'later_trakt':
        out = bool(st.get('pendiente_trakt'))
        _cine(lambda: cine.call('pendiente', usuario=user, titulo_o_id=item_id, quitar=out),
              ('Quitado de Ver más tarde: ' if out else 'Añadido a Ver más tarde (Trakt): ') + name)
    elif chosen == 'rate':
        rate(addon_path, o, st)
    elif chosen == 'nope':
        if _cine(lambda: cine.call('no_me_interesa', usuario=user, titulo_o_id=item_id),
                 'No te lo volverá a recomendar: ' + name):
            later.refresh()   # it leaves Watch Later too
    elif chosen == 'watched':
        want = not o.get('UserData', {}).get('Played')
        try:
            jellyfin.call('/Users/{user}/PlayedItems/%s' % item_id, 'POST' if want else 'DELETE')
            said = ('Marcado como visto: ' if want else 'Marcado como no visto: ') if o.get('Type') == 'Episode' else \
                ('Marcada como vista: ' if want else 'Marcada como no vista: ')
            xbmcgui.Dialog().notification('Free My TV', said + name, xbmcgui.NOTIFICATION_INFO, 3000)
            # Continue Watching, Next Up and the tabs showing it or its series (their marks) change; not every tab
            shown = {item_id, o.get('SeriesId')} - {None, ''}
            settings.reload_tabs(settings.holding(shown, ('resume', 'nextup')), fetch=True)
        except Exception as e:
            xbmc.log('Free My TV, watched: %s' % e, xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Free My TV', 'No se pudo marcar: %s' % e, xbmcgui.NOTIFICATION_WARNING, 4000)
    elif chosen == 'similar':   # in Home's grid, as the TV's; Back brings the tab back
        settings.similar(item_id)
        xbmcgui.Dialog().notification('Más como esto', name, xbmcgui.NOTIFICATION_INFO, 3000, False)
    elif chosen == 'series':
        import series
        series.show(addon_path, o['SeriesId'])
    elif chosen == 'more':   # JellyCon's own menu, this time not sent here
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.jellycon/?mode=SHOW_MENU&item_id=%s&fmt_full=1)' % item_id)


def after_watching(addon_path):
    """«¿Qué te pareció?» at the bottom, once, for what this profile has just finished: a movie, or a series' last
    episode (asked about the series), when palantir-cine says so (preguntar_opinion: Trakt linked, not a child's, not
    rated, not asked yet here or on the TV); it goes after 15 s."""
    import calendar
    import time
    home = xbmcgui.Window(10000)
    if xbmc.Player().isPlaying():   # something else started meanwhile
        return
    recent = jellyfin.call('/Users/{user}/Items?SortBy=DatePlayed&SortOrder=Descending&Limit=1&Recursive=true'
                           '&IncludeItemTypes=Movie,Episode&Filters=IsPlayed&EnableImages=false'
                           '&Fields=DateCreated').get('Items', [])
    if not recent:
        return
    o = recent[0]
    played = ((o.get('UserData') or {}).get('LastPlayedDate') or '')[:19]
    if not played or time.time() - calendar.timegm(time.strptime(played, '%Y-%m-%dT%H:%M:%S')) > 600:
        return   # nothing finished just now (Jellyfin's dates are UTC)
    if o.get('Type') == 'Episode':
        episodes = jellyfin.call('/Shows/%s/Episodes?UserId={user}&EnableImages=false' % o.get('SeriesId')).get('Items', [])
        if not episodes or episodes[-1].get('Id') != o.get('Id'):
            return   # not the last one yet
        o = jellyfin.call('/Users/{user}/Items/%s?Fields=Genres&EnableImages=false' % o['SeriesId'])
    if home.getProperty('fmt_asked') == o.get('Id'):
        return
    home.setProperty('fmt_asked', o.get('Id', ''))
    if not cine.config():
        return
    try:   # the server decides (Trakt, not a child's, not rated, not asked yet on the TV either) and notes it
        st = cine.call('preguntar_opinion', timeout=4, usuario=who.name(), titulo_o_id=o['Id'])
    except Exception as e:
        xbmc.log('Free My TV, palantir-cine: %s' % e, xbmc.LOGWARNING)
        return
    if not st.get('preguntar'):
        return
    rate(addon_path, o, st, '¿Qué te pareció?', seconds=15)
