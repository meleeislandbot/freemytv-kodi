"""How Home's tabs' grids are loading (each tab's is kept loaded: install.py's GRID), as the TV's (Jellyfin.progress):
the notices' pill says «Actualizando las listas…  3/11» while any is, and a tab still to come carries a dot after its
name (fmt_tab<N>_mark).
"""
import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
GRID, SLOTS = 9100, 12


def watch(monitor):
    marks = {}
    while not monitor.waitForAbort(0.4):
        if not xbmc.getCondVisibility('Window.IsVisible(home)'):
            continue
        tabs = [i for i in range(1, SLOTS + 1) if HOME.getProperty('fmt_tab%d_name' % i)]
        loading = {i for i in tabs if xbmc.getCondVisibility('Container(%d).IsUpdating' % (GRID + i))}
        HOME.setProperty('fmt_progress', '%d/%d' % (len(tabs) - len(loading), len(tabs)) if loading else '')
        for i in tabs:
            mark = '•' if i in loading else ''
            if marks.get(i) != mark:   # each property set waits for the GUI's next frame: only changes
                HOME.setProperty('fmt_tab%d_mark' % i, mark)
                marks[i] = mark
