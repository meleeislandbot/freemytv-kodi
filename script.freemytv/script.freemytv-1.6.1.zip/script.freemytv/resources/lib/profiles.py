"""«¿Quién está viendo?» (script-freemytv-profiles.xml), as the TV's ProfilesActivity: the Jellyfin users JellyCon has
signed in on this box (its auth.json keeps each one's token), and «Añadir», JellyCon's own sign-in (its Quick Connect
code first). OK on one: JellyCon goes on as that user, as its own «Cambiar usuario» does (its username setting and its
Window(home) property; the patch in jellycon_fixes.py makes its service follow), and Home gets that user's tabs
(who.own), Continue Watching, watched marks and Watch Later. The service opens it at start and when the box wakes,
with two users or more. What a profile may watch is set on the server (its user's parental control), not here.
"""
import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import held
import who

HOME = xbmcgui.Window(10000)
LIST = 700
BACK = (9, 10, 92)
STEP = 312   # a disc's room in the row (install.py's profiles_window)
# The TV's colours (ProfilesActivity.color), picked by the name, so a profile has the same one on both
COLORS = ('FFFF4FBF', 'FF0A84FF', 'FFFF9F0A', 'FF30D158', 'FFBF5AF2', 'FF64D2FF')
AUTH = 'special://profile/addon_data/plugin.video.jellycon/auth.json'
# The guest profile: the usual grey silhouette instead of an initial (the TV's ProfilesActivity.guest)
GUESTS = ('invitado', 'invitados', 'guest', 'guests', 'convidado', 'convidados', 'gast', 'gäste', 'гость', 'гости')


def users():
    """The names JellyCon keeps a sign-in for, by name (only the names: the tokens stay JellyCon's)."""
    try:
        with open(xbmcvfs.translatePath(AUTH), encoding='utf-8') as f:
            return sorted(json.load(f), key=str.lower)
    except (OSError, ValueError):
        return []


def color(name):
    return COLORS[sum(map(ord, name.lower())) % len(COLORS)]


def guest(name):
    return name.strip().lower() in GUESTS


def publish():
    """The profile in use for Home's disc in the title row: its initial and colour."""
    name = who.name()
    HOME.setProperty('fmt_profile', name)
    HOME.setProperty('fmt_profile_letter', '' if guest(name) else name[:1].upper())
    HOME.setProperty('fmt_profile_color', 'FFFFFFFF' if guest(name) else color(name) if name else '00000000')
    HOME.setProperty('fmt_profile_disc', 'freemytv/guest_52.png' if guest(name) else 'freemytv/disc_52.png')


def use(name):
    """JellyCon goes on as that user; the service sees it (watch) and gives Home their tabs and lists."""
    if name == who.name():
        return
    xbmcaddon.Addon('plugin.video.jellycon').setSetting('username', name)
    HOME.setProperty(who.PROPERTY, name)
    xbmc.log('Free My TV: profile %s' % name, xbmc.LOGINFO)


def play_as(user, item_id, source='', ticks='0'):
    """The TV's «Ver en Kodi» (Jellyfin.playOn, over JSON-RPC): Kodi goes on as the TV's profile if it's on another,
    then plays the title as them (the version the TV chose, from where they left it), so progress is theirs."""
    name = next((n for n in users() if n.lower() == user.strip().lower()), None)
    if name is None:   # never signed in here: JellyCon's own sign-in is theirs to do
        xbmcgui.Dialog().notification('Free My TV', '%s no ha entrado en este Kodi' % user, xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    use(name)   # the plugin below reads JellyCon's user afresh; its service follows (jellycon_fixes)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.jellycon/?item_id=%s&mode=PLAY%s&auto_resume=%d")'
                        % (item_id, '&media_source_id=' + source if source else '', int(ticks or 0)))


class Profiles(xbmcgui.WindowXMLDialog):
    names = ()
    chosen = None   # a name, '+' to add one
    backdrop = ''   # Home's focused title, blurred (settings.backdrop)

    def onInit(self):
        self.setProperty('backdrop', self.backdrop)
        now = who.name()
        items = []
        for n in self.names:
            li = xbmcgui.ListItem(n)
            li.setProperty('letter', '' if guest(n) else n[:1].upper())
            li.setProperty('color', 'FFFFFFFF' if guest(n) else color(n))
            li.setProperty('disc', 'freemytv/guest_profile.png' if guest(n) else 'freemytv/disc_profile.png')
            items.append(li)
        add = xbmcgui.ListItem('Añadir', 'otro usuario de Jellyfin[CR]con Quick Connect')
        add.setProperty('letter', '+')
        add.setProperty('color', '0FFFFFFF')
        add.setProperty('disc', 'freemytv/disc_profile.png')
        items.append(add)
        control = self.getControl(LIST)
        control.reset()
        control.addItems(items)
        control.setWidth(len(items) * STEP)
        control.setPosition((1920 - len(items) * STEP) // 2, 400)
        self.setFocusId(LIST)
        if now in self.names:
            control.selectItem(list(self.names).index(now))
        held.mark()

    def onClick(self, control):
        if held.repeat():   # the OK that opened this still held
            return
        if control == LIST:
            at = self.getControl(LIST).getSelectedPosition()
            self.chosen = self.names[at] if at < len(self.names) else '+'
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


def show(addon_path):
    window = Profiles('script-freemytv-profiles.xml', addon_path, 'Default', '1080i')
    window.names = users()
    import settings
    window.backdrop = settings.backdrop()   # read while Home is still on top
    window.doModal()
    chosen = window.chosen
    del window
    if chosen == '+':   # JellyCon's sign-in: its Quick Connect code, approved by the new user in Jellyfin
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.jellycon/?mode=CHANGE_USER)')
    elif chosen:
        use(chosen)


def due():
    """At start and on waking: with two profiles or more, who's watching."""
    return len(users()) > 1 and not xbmc.Player().isPlaying()


def watch(monitor, changed):
    """Calls changed() whenever JellyCon's user changes (here, or its own «Cambiar usuario»)."""
    last = who.name()
    publish()
    while not monitor.waitForAbort(1):
        now = HOME.getProperty(who.PROPERTY) or last   # JellyCon clears it while its service starts
        if now != last:
            last = now
            publish()
            changed()
