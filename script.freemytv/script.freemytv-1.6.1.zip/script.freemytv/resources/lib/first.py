"""The first tab at start, from a copy: at start ten add-ons take turns in Python, and JellyCon's list comes about 10 s
after Home shows. So the service keeps what JellyCon last served for the first tab (read off the grid, as Kodi shows
it) in first.json, plugin.py serves that copy at once, and JellyCon's list replaces it when it comes: the same items
(their paths are JellyCon's), so the grid keeps its focus.
"""
import json
import os

import xbmc
import xbmcvfs

import who

FILE = 'special://profile/addon_data/script.freemytv/first.json'
GRID = 'Container(9101).ListItemAbsolute(%d).'   # the first tab's grid (install.py's GRID + 1)
LABELS = ('Label', 'FileNameAndPath', 'Art(poster)', 'Art(thumb)', 'Art(tvshow.poster)', 'Art(fanart)', 'Rating',
          'Year', 'Genre', 'Mpaa', 'Plot', 'Tag', 'Property(ItemType)', 'Property(id)', 'Property(later)')


def key():
    """The address (without its reload) of the list the copy holds, or '' when there's none."""
    try:
        with open(xbmcvfs.translatePath(who.own(FILE)), encoding='utf-8') as f:   # the profile's own (who.py)
            return json.load(f).get('key', '')
    except (OSError, ValueError):
        return ''


def grid(condition):
    return xbmc.getCondVisibility(condition)


def wait(monitor, condition, seconds):
    """True once the condition holds, False after the seconds or when Kodi quits."""
    for _ in range(seconds * 4):
        if grid(condition):
            return True
        if monitor.waitForAbort(0.25):
            return False
    return False


def shown(monitor):
    """Waits until the grid shows the copy (or anything): then JellyCon can be asked behind it."""
    return wait(monitor, 'Integer.IsGreater(Container(9101).NumItems,0)', 20)


def keep(monitor, address):
    """Once JellyCon's list for the first tab is in (no item marked as the copy's), keeps it as the copy. address is
    that list's, without its reload; nothing is kept if the first tab isn't the one showing by then."""
    done = ('Integer.IsGreater(Container(9101).NumItems,0) + !Container(9101).IsUpdating'
            ' + String.IsEmpty(Container(9101).ListItemAbsolute(0).Property(fmt_copy))')
    if not wait(monitor, done, 60):
        return
    if xbmc.getInfoLabel('Window(home).Property(fmt_tab)') not in ('', '1'):
        return
    count = int(xbmc.getInfoLabel('Container(9101).NumItems') or 0)
    items = []
    for i in range(count):
        item = {label: xbmc.getInfoLabel(GRID % i + label) for label in LABELS}
        item['folder'] = grid('Container(9101).ListItemAbsolute(%d).IsFolder' % i)
        items.append(item)
    path = xbmcvfs.translatePath(who.own(FILE))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + '.new', 'w', encoding='utf-8') as f:
        json.dump({'key': address, 'items': items}, f, ensure_ascii=False)
    os.replace(path + '.new', path)
    xbmc.log('Free My TV: first tab kept for the next start (%d titles)' % len(items), xbmc.LOGINFO)
