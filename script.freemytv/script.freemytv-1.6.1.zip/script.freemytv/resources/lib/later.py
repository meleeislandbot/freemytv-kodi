"""Watch Later, shared with the TV: the same Jellyfin playlist (hold OK on a poster: Kodi's context menu). The titles in
it are kept in Window(home).Property(fmt_later), " id id ", so the skin marks their posters.
"""
import xbmc
import xbmcgui

import jellyfin

HOME = xbmcgui.Window(10000)


def ids():
    return [i for i in HOME.getProperty('fmt_later').split() if i]


def refresh():
    """Reads the playlist again (the TV may have changed it)."""
    try:
        HOME.setProperty('fmt_later', ' %s ' % ' '.join(jellyfin.later_ids()))
    except Exception as e:   # JellyCon signed out or the server away: the marks stay as they were
        xbmc.log('Free My TV, watch later: %s' % e, xbmc.LOGWARNING)


def toggle(item_id, title=''):
    """Adds the title or takes it out, says so, and updates the marks; True when added."""
    try:
        added = jellyfin.toggle_later(item_id)
    except Exception as e:
        xbmcgui.Dialog().notification('Ver más tarde', 'No se pudo cambiar: %s' % e, xbmcgui.NOTIFICATION_WARNING, 4000)
        return item_id in ids()
    current = [i for i in ids() if i != item_id] + ([item_id] if added else [])
    HOME.setProperty('fmt_later', ' %s ' % ' '.join(current))
    xbmcgui.Dialog().notification('Ver más tarde', ('Añadido: ' if added else 'Quitado: ') + title,
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    import settings
    settings.add_later_tab()   # the first time: its tab comes with it
    settings.publish(fresh=True)   # the tabs ask again (Watch Later's shows the change)
    return added
