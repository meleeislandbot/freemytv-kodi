"""Runs while Kodi does: Watch Later's marks every few minutes (the TV may add titles too), and the home screen's tabs
from the settings (settings.publish), once at start and whenever they change, and the master collections' ids
(filters.remember), so the filters don't wait for the server; and where Home's panel puts the facts (panel.watch).
JellyCon's changes go in at start and every few minutes (jellycon_fixes); a fresh install gets its first tabs once
JellyCon is signed in (settings.defaults).
"""
import os
import sys

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

import first  # noqa: E402
import panel  # noqa: E402
import settings  # noqa: E402

# The tabs first: at start ten add-ons load Python at once and take turns, so an import like urllib.request (later's,
# through jellyfin) takes 2 s there, and the grid can't ask for its list until the tabs are out. The first tab shows
# the copy of its last list (first.py) while JellyCon is asked for it behind.
monitor = xbmc.Monitor()
# Where Home's panel puts the facts, first: until it has, they could lie over a long title
__import__('threading').Thread(target=panel.watch, args=(monitor,), daemon=True).start()
address = settings.first_address()
if address and first.key() == address:
    settings.publish(copy=address)
    first.shown(monitor)
settings.publish()


def fresh():
    """A fresh install's first tabs (settings.defaults), once JellyCon is signed in: tried every few seconds till then."""
    while True:
        try:
            settings.save(settings.defaults())
            break
        except Exception:   # not signed in yet, or the server away
            if monitor.waitForAbort(10):
                return
    settings.publish()


if not settings.saved():
    __import__('threading').Thread(target=fresh, daemon=True).start()
import jellycon_fixes  # noqa: E402

jellycon_fixes.in_kodi()
import later  # noqa: E402

import filters  # noqa: E402

if address:
    first.keep(monitor, address)
if filters.remember():
    settings.publish()   # the Cortos tab's kinds found or changed
try:   # JellyCon's image cache on the screensaver off in Kodi's memory too: install.py's edit of its file holds only until
    # JellyCon saves its settings. It asked the server for the whole library each time and ran it out of memory.
    __import__('xbmcaddon').Addon('plugin.video.jellycon').setSetting('cacheImagesOnScreenSaver', 'false')
except RuntimeError:   # no JellyCon
    pass
import popular  # noqa: E402
import tracks  # noqa: E402

watcher = tracks.Watcher()   # the player's version button (kept: Kodi calls it while it lives)

top = xbmc.getInfoLabel('Window(home).Property(fmt_popular)')
if popular.refresh(top):
    settings.publish()   # the month's most watched in Trakt's order (yesterday's until now)
while not monitor.abortRequested():
    jellycon_fixes.in_kodi()   # back in after JellyCon updates itself
    later.refresh()
    if xbmc.getInfoLabel('Window(home).Property(fmt_tabs_day)') != __import__('time').strftime('%Y-%m-%d'):
        with settings.updating():
            popular.refresh(xbmc.getInfoLabel('Window(home).Property(fmt_popular)'))
            filters.refresh_saved()   # the saved filters' tabs: today's titles
            settings.publish()   # a new day: New Releases up to today, the most watched in today's order
            filters.remember()
    elif not xbmc.getInfoLabel('Window(home).Property(fmt_masters)'):
        filters.remember()   # the server too slow at start
    top = xbmc.getInfoLabel('Window(home).Property(fmt_popular)')
    if top and popular.stale(top):   # the TV changed the month's most watched: in Trakt's order again
        with settings.updating():
            if popular.refresh(top, force=True):
                settings.publish()
    if monitor.waitForAbort(300):
        break
