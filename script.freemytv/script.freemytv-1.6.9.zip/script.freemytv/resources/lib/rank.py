"""The search's order, as the TV's (SearchRank.java): what you meant first.

- A title or a saga that is what's typed ("piratas del caribe", "terminator") comes first, its films together and in
  order (by year); then the titles that start that way, each saga together, the best rated saga first; then those with
  every word typed somewhere in the title; then the rest (typos, synopsis) in the server's order.
- Someone whose name is what's typed ("ryan gosling", "tom han") comes before all that; with a single word ("gosling",
  "scarlett"), whoever the synopses of the matches name the most. Three people at most.
- Typos count as in the server's search (Meilisearch): one from 5 letters, two from 9; the last word may be unfinished.
- What's better known goes first: IMDb's votes when palantir-cine gives them (popularidad), else the rating.
"""
import math
import re
import unicodedata

CONNECTORS = {'y', 'e', 'and', 'de', 'del', 'of', 'the', 'la', 'el', 'los', 'las', 'en', 'contra', 'vs'}
ARTICLES = {'el', 'la', 'los', 'las', 'lo', 'un', 'una', 'the', 'a', 'an', 'le', 'les', 'il', 'der', 'die', 'das'}
SEQUEL = re.compile(r'(?: (?:\d+|[ivx]+|(?:parte|part|capitulo|chapter|vol|volumen|episodio|episode) \w+))+$')
HEAD = re.compile(r'\s*[:–—]\s*|\s+-\s+|,\s+|\.\s+')
PEOPLE = 3
KNOWN = 1.5   # a saga's own: at most this much less known than its best (some 30 times fewer votes)


def plain(s):
    """Lowercase words without accents or punctuation ("¡Piratas!" is "piratas", "Alien³" is "alien3")."""
    s = unicodedata.normalize('NFKD', (s or '').lower())
    return ' '.join(re.sub(r'[^0-9a-z]+', ' ', ''.join(c for c in s if not unicodedata.combining(c))).split())


def head(title):
    """A saga's name: before «:», sequel numbers off ("Terminator 2: El juicio final" is "terminator")."""
    return SEQUEL.sub('', plain(HEAD.split(title or '', 1)[0]))


def typos(n):
    return 2 if n >= 9 else 1 if n >= 5 else 0


def distance(a, b, most):
    """Edit distance, or most + 1 as soon as it's past most."""
    if abs(len(a) - len(b)) > most:
        return most + 1
    row = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        prev, row[0] = row[0], i
        best = row[0]
        for j, cb in enumerate(b, 1):
            prev, row[j] = row[j], min(row[j] + 1, row[j - 1] + 1, prev + (ca != cb))
            best = min(best, row[j])
        if best > most:
            return most + 1
    return row[-1]


def word(q, w, unfinished, fuzzy):
    """The typed word q is the word w (unfinished: or its start); fuzzy: with the server's typos (the start of a word
    only from 8 letters: "matrix" isn't "matrimonio")."""
    if w == q or unfinished and w.startswith(q):
        return True
    most = typos(len(q)) if fuzzy else 0
    if not most:
        return False
    return distance(q, w, most) <= most or (unfinished and len(q) >= 8 and len(w) > len(q)
                                            and distance(q, w[:len(q)], most) <= most)


def starts(q, w, unfinished, fuzzy):
    return len(w) >= len(q) and all(word(a, b, unfinished and i == len(q) - 1, fuzzy)
                                    for i, (a, b) in enumerate(zip(q, w)))


def tier(q, name, saga=None, fuzzy=False):
    """0 it's what's typed (or its saga is), 1 it starts so, 2 every word typed is in it, 3 none of that."""
    best = 3
    for words in ([name.split()] + ([saga.split()] if saga is not None else [])):
        for w in (words, words[1:] if len(words) > 1 and words[0] in ARTICLES and words[0] != q[0] else None):
            if not w:
                continue
            if len(w) == len(q) and starts(q, w, False, fuzzy):
                return 0
            if starts(q, w, True, fuzzy):
                best = min(best, 1)
    if best == 3 and all(any(word(a, b, True, fuzzy) for b in name.split()) for a in q):
        best = 2
    return best


def known(t, votes):
    """How well known a title is: log of IMDb's votes and a bit of its rating; without votes, the rating and whether
    critics reviewed it (Rotten Tomatoes: CriticRating)."""
    rating = t.get('CommunityRating') or 0
    if votes is not None:
        return math.log10(votes.get(t.get('Id', '').replace('-', '').lower(), 0) + 1) + rating * 0.3
    return rating * 0.6 + (1.5 if t.get('CriticRating') is not None else 0)


def ranked(typed, titles, people, votes=None):
    """titles: the server's matches, in its order ({Id, Name, OriginalTitle, ProductionYear, CommunityRating,
    CriticRating, Overview}); people: [{Name, ImageTags}]; votes: {id: IMDb votes} (palantir-cine) or None. The order
    to show them in (titles and people mixed)."""
    q = plain(typed).split()
    if not q:
        return titles
    blocks = []   # (band, -score, first, [items]): 0 starts as typed, 1 so with typos, 2 every word in it, 3 the rest
    sagas = {}
    for n, t in enumerate(titles):
        names = [x for x in (t.get('Name'), t.get('OriginalTitle')) if x]
        best = min(tier(q, plain(x), head(x)) for x in names)
        if best == 3:
            best = min(tier(q, plain(x), head(x), True) for x in names)
            band = 1 if best <= 1 else best
        else:
            band = 0 if best <= 1 else 2
        if band == 3:
            blocks.append((3, 0, n, [t]))
            continue
        # Its saga: the start of its name, as long as what's typed (and «y», «del»... after it: «Harry Potter y»).
        words = head(t.get('Name')).split()
        words = words[1:] if len(words) > 1 and words[0] in ARTICLES else words
        if band < 2:
            words = words[:len(q) + 1] if len(words) > len(q) and words[len(q)] in CONNECTORS else words[:len(q)]
        key = (band, ' '.join(words))
        saga = sagas.setdefault(key, dict(items=[], score=-1.0, first=n))
        score = known(t, votes)
        saga['items'].append((score, t))
        saga['score'] = max(saga['score'], score + (1 if best == 0 else 0))
    for (band, _), s in sagas.items():
        # The saga's own, by year (films, then series); its little-known ones (rip-offs, specials) after, best first.
        top = max(score for score, _ in s['items'])
        main = sorted((t for score, t in s['items'] if score >= top - KNOWN),
                      key=lambda t: (t.get('Type') == 'Series', t.get('ProductionYear') or 9999))
        rest = [t for score, t in sorted(s['items'], key=lambda x: -x[0]) if score < top - KNOWN]
        blocks.append((band, -s['score'], s['first'], main + rest))
    synopses = [plain(t.get('Overview')) for t in titles]
    found = []
    for n, p in enumerate(people):
        name = plain(p.get('Name'))
        level = tier(q, name)
        if level == 3:   # only with typos ("harry potter": Harry Porter): never before the titles
            if tier(q, name, fuzzy=True) == 3:
                continue
            level = 4
        mentions = sum(name in s for s in synopses) if len(name.split()) > 1 else 0
        found.append((level, -mentions, not p.get('ImageTags', {}).get('Primary'), n, mentions, p))
    found.sort(key=lambda f: f[:4])
    for level, _, _, n, mentions, p in found[:PEOPLE]:
        if len(q) > 1 and level <= 1:   # a name and surname typed: they're who you mean
            blocks.append((0, -(100 if level == 0 else 12) - mentions, n - 1000, [p]))
        elif mentions >= 2:   # one word, and the matches' synopses name them: likely them
            blocks.append((0, -10 - min(mentions, 9) / 10, n - 1000, [p]))
        else:
            blocks.append((2, 100, n - 1000, [p]))   # after the titles with every word, before the rest
    blocks.sort(key=lambda b: b[:3])
    return [item for b in blocks for item in b[3]]
