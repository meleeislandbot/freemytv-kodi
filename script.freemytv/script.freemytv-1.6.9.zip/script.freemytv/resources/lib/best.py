"""The version JellyCon plays when a title has several, chosen as the TV chooses it for «Ver en Ugoos»
(Jellyfin.playableSource and quality): JellyCon calls best() through install.py's patch instead of asking. With
«Elegir la mejor versión» off (the add-on's settings, auto_version) it chooses none, so JellyCon lists them to pick one.

A version streamed from an address (a service that fetches it on demand) is asked for, all at once: one it can't find
answers 502, and one it finds redirects to the file, whose name usually says its codec and size ("… (av1) (5,16 G).mkv").
"""
import http.client
import re
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
except ImportError:   # python3 best.py, outside Kodi: the self-check at the end
    xbmc = xbmcaddon = xbmcgui = None


def auto():
    """Whether to choose the version without asking (on unless turned off in the add-on's settings)."""
    try:
        return xbmcaddon.Addon('script.freemytv').getSetting('auto_version') != 'false'
    except Exception:
        return True


def best(sources):
    """The best version that answers, or None when none does or it's to be asked (JellyCon then lists them)."""
    if not auto():
        xbmc.log('Free My TV, best version: asking, as set', xbmc.LOGINFO)
        return None
    remote = any((s.get('Path') or '').startswith('http') for s in sources)
    if remote:
        xbmcgui.Dialog().notification('Free My TV', 'Buscando la mejor versión…', xbmcgui.NOTIFICATION_INFO, 3000, False)
    with ThreadPoolExecutor(max_workers=4) as pool:
        files = list(pool.map(lambda s: file_at(s.get('Path') or '') if (s.get('Path') or '').startswith('http')
                              else s.get('Path') or '', sources))
    chosen, top = None, None
    for s, f in zip(sources, files):
        if f is None:
            xbmc.log('Free My TV, best version: %s doesn\'t answer' % s.get('Name'), xbmc.LOGINFO)
            continue
        q = quality(s, f)
        xbmc.log('Free My TV, best version: %s = %s' % (s.get('Name'), f), xbmc.LOGINFO)
        if top is None or q > top:
            chosen, top = s, q
    xbmc.log('Free My TV, best version: chose %s' % (chosen or {}).get('Name'), xbmc.LOGINFO)
    return chosen


def quality(s, file):
    """How good a version is for an Amlogic box: Dolby Vision, then HDR, then the picture's width, then its size (the
    remux: Dolby Vision's FEL layer, lossless audio). AV1 comes last: these chips can't decode it, so a 4K one stutters
    in software. Read from the server's data, or from the version's and file's names."""
    text = ' %s ' % re.sub(r'[^a-z0-9,.]+', ' ', ('%s %s' % (s.get('Name') or '', file)).lower())
    width, video_range, codec = 0, '', ''
    for st in s.get('MediaStreams') or []:
        if st.get('Type') == 'Video':
            width = max(width, st.get('Width') or 0)
            video_range = ('%s%s' % (st.get('VideoRangeType') or '', st.get('VideoRange') or '')).upper()
            codec = (st.get('Codec') or '').lower()
    if not width:
        width = (3840 if re.search(r' (2160p?|4k|uhd) ', text) else 2560 if ' 1440p ' in text else
                 1920 if ' 1080p ' in text else 1280 if ' 720p ' in text else
                 3840 if re.search(r' (dv|dovi|dolby vision|hdr\w*) ', text) else 0)
    dv = 'DOVI' in video_range or re.search(r' (dv|dovi|dolby vision) ', text) is not None
    hdr = 'HDR' in video_range or re.search(r' hdr\w* ', text) is not None
    av1 = codec == 'av1' or ' av1 ' in text
    size = (s.get('Size') or 0) // 1000000   # MB
    gb = re.search(r' (\d+(?:[.,]\d+)?) ?gb? ', text)
    if not size and gb:
        size = round(float(gb.group(1).replace(',', '.')) * 1000)
    return (0 if av1 else 1 << 40) + (width * 10 + (2 if dv else 1 if hdr else 0)) * 1000000 + min(size, 999999)


def file_at(url):
    """Where the address leads: the file's name once it redirects to it (or the address itself when it answers with the
    file), or None if it doesn't answer (a service that can't find the file gives 502)."""
    try:
        u = urllib.parse.urlsplit(url)
        connection = (http.client.HTTPSConnection if u.scheme == 'https' else http.client.HTTPConnection)(u.netloc, timeout=25)
        try:
            connection.request('GET', (u.path or '/') + ('?' + u.query if u.query else ''), headers={'Range': 'bytes=0-0'})
            answer = connection.getresponse()   # not followed: the redirect itself says the file was found, and where
            if not 200 <= answer.status < 400:
                return None
            at = answer.getheader('Location') if answer.status >= 300 and answer.getheader('Location') else url
            return urllib.parse.unquote(re.sub(r'[?#].*', '', at).rsplit('/', 1)[-1])
        finally:
            connection.close()
    except (OSError, ValueError, http.client.HTTPException):
        return None


if __name__ == '__main__':   # python3 best.py: the order, on made-up versions
    names = {'[DV HDR10]': 'Movie (2019) 2160p DV HDR10 hevc (58,2 G).mkv', '[4K]': 'Movie 2160p (av1) (12 G).mkv',
             '[1080p]': 'Movie 1080p x264 (9,1 G).mkv', '[4K HDR10]': 'Movie 2160p HDR10 hevc (21 G).mkv'}
    ranked = sorted(names, key=lambda n: quality({'Name': n}, names[n]), reverse=True)
    assert ranked == ['[DV HDR10]', '[4K HDR10]', '[1080p]', '[4K]'], ranked
    print('ok', ranked)
