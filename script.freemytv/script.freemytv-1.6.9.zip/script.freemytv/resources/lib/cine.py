"""palantir-cine, the server's film agent (MCP over HTTP): a title's state for the quick actions (in Watch Later, your
Trakt rating, not interested), rating it in Trakt, «not interested», and a series to Trakt's watchlist (a Jellyfin
playlist can't hold one). Each profile's own Trakt is linked on the server, not on this box.

Its address and key are config.properties' cine_url and cine_token, which install.py copies to cine.json here, or, on a
Kodi from the repository, the add-on's settings (the key never goes to the screen or the log). Without them the quick
actions are as before.
"""
import json
import os

import xbmcvfs

FOLDER = 'special://profile/addon_data/script.freemytv/'


def config():
    """cine.json (install.py's), else the add-on's own settings (a Kodi from the repository), or None."""
    try:
        with open(os.path.join(xbmcvfs.translatePath(FOLDER), 'cine.json'), encoding='utf-8') as f:
            c = json.load(f)
    except (OSError, ValueError):
        import xbmcaddon
        addon = xbmcaddon.Addon('script.freemytv')
        c = {'url': addon.getSetting('cine_url').strip(), 'token': addon.getSetting('cine_token').strip()}
    return c if c.get('url') and c.get('token') else None


def call(tool, timeout=6, **arguments):
    """The tool's answer (JSON); RuntimeError with the server's own words when it says no."""
    import urllib.request
    c = config()
    if not c:
        raise RuntimeError('sin palantir-cine (cine_url y cine_token en config.properties)')
    body = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                       'params': {'name': tool, 'arguments': arguments}}).encode()
    request = urllib.request.Request(c['url'], data=body, method='POST', headers={
        'Authorization': 'Bearer ' + c['token'], 'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream', 'MCP-Protocol-Version': '2025-06-18'})
    with urllib.request.urlopen(request, timeout=timeout) as r:
        answer = json.loads(r.read())
    result = answer.get('result') or {}
    text = ''.join(part.get('text', '') for part in result.get('content') or [])
    if answer.get('error') or result.get('isError'):
        raise RuntimeError(text.split(': ', 1)[-1] if text else str(answer.get('error')))
    return json.loads(text) if text else {}


def state(user, item_id):
    """The title's state for this profile, or None (no palantir-cine, or it didn't answer in time)."""
    if not config():
        return None
    try:
        return call('estado_titulo', timeout=3, usuario=user, titulo_o_id=item_id)
    except Exception as e:
        import xbmc
        xbmc.log('Free My TV, palantir-cine: %s' % e, xbmc.LOGWARNING)
        return None


# The quick ratings (Trakt's 1-10), and every one for «Nota exacta…»
QUICK = ((9, 'Me encantó'), (7, 'Me gustó'), (3, 'No me gustó'))
WORDS = {10: 'Obra maestra', 9: 'Excelente', 8: 'Muy buena', 7: 'Buena', 6: 'Pasable', 5: 'Regular', 4: 'Floja',
         3: 'Mala', 2: 'Muy mala', 1: 'Horrible'}
