"""Free My TV's search for Kodi, as on the TV (SearchActivity): the keyboard on the left, alphabetical, six to a row,
and on the right the best matches in the Jellyfin library, asked for again at each pause in typing; before typing,
the month's most watched. OK on a match opens or plays it. The window (script-freemytv-search.xml) is the Free My TV
skin's; JellyCon fetches the matches (its server search forgives typos with a plugin such as Meilisearch).

RunScript(script.freemytv,search,<collection id of the month's most watched>)
"""
import threading
from urllib.parse import quote

import xbmc
import xbmcgui

import jellyfin
import series

HOME = xbmcgui.Window(10000)
LETTERS = ['abcdef', 'ghijkl', 'mnopqr', 'stuvwx', "yzñ'-."]
DIGITS = ['123456', '7890.,', "-'&:!?", '()/@#+', '%*=;_"']
KEYS, ABC, NUMBERS, SPACE, DELETE, CLEAR = 200, 240, 241, 250, 251, 252
MATCHES, SUGGESTIONS = 300, 310
FIELDS = ('&IsVirtualUnAired=false&IsMissing=false&Fields=PremiereDate,ProductionYear,Genres,CommunityRating,'
          'OfficialRating,Tags,Overview&format=json')
PAUSE = 0.25   # one question per pause in typing, not one per letter
BACK = (9, 10, 92)   # parent dir, previous menu, back
REMOTE_DIGITS = range(58, 68)   # the remote's 0-9


def ranked(typed, limit=8):
    """The server's matches (nearly alphabetical: 60 asked for) and the people, in the order you meant, as the TV's
    (rank.py, SearchActivity's SearchRank): people, titles and palantir-cine's votes asked for at once."""
    import rank
    found = {}

    def ask(key, path):
        try:
            found[key] = jellyfin.call(path).get('Items', [])
        except Exception as e:   # people are the lesser part: the titles still
            xbmc.log('Free My TV search %s: %s' % (key, e), xbmc.LOGWARNING)
            found[key] = []
    asks = [threading.Thread(target=ask, args=a) for a in (
        ('searched', '/Users/{user}/Items?SearchTerm=%s&IncludeItemTypes=Person&Recursive=true&EnableTotalRecordCount=false'
                     '&Limit=24' % jellyfin.q(typed)),
        ('listed', '/Persons?searchTerm=%s&limit=12&userId={user}' % jellyfin.q(typed)))]
    for a in asks:
        a.start()
    titles = jellyfin.call('/Users/{user}/Items?SearchTerm=%s&IncludeItemTypes=Movie,Series&Recursive=true&Limit=60'
                           '&EnableTotalRecordCount=false&EnableImages=false&EnableUserData=false'
                           '&Fields=CommunityRating,OriginalTitle,Overview,ProductionYear' % jellyfin.q(typed)).get('Items', [])
    votes = None
    try:
        import cine
        if cine.config() and titles:
            votes = cine.call('popularidad', timeout=2, ids=[t['Id'] for t in titles])
    except Exception as e:   # without palantir-cine's votes: by rating
        xbmc.log('Free My TV search votes: %s' % e, xbmc.LOGWARNING)
    for a in asks:
        a.join()
    people, seen = [], set()
    for p in found.get('searched', []) + found.get('listed', []):
        if p.get('Id') not in seen:
            seen.add(p.get('Id'))
            people.append(p)
    return [o['Id'] for o in rank.ranked(typed, titles, people, votes)[:limit]]


def jellycon(url):
    return ('plugin://plugin.video.jellycon/?url=' + quote(url + FIELDS, safe='/')
            + '&mode=GET_CONTENT&media_type=Playlist&sort=none')


class Search(xbmcgui.WindowXMLDialog):
    text = ''
    digits = False
    popular = ''
    chosen = None   # (path, is a folder) of the match picked, opened once the window is closed
    timer = None

    def onInit(self):
        # Set here: Kodi reads a label that's only digits ("123") as the number of a translated string.
        self.getControl(NUMBERS).setLabel('123')
        self.mode(False)
        self.refresh()
        self.setFocusId(KEYS)

    def onClick(self, control):
        if KEYS <= control < KEYS + 30:
            rows = DIGITS if self.digits else LETTERS
            self.type(rows[(control - KEYS) // 6][(control - KEYS) % 6])
        elif control in (ABC, NUMBERS):
            self.mode(control == NUMBERS)
        elif control == SPACE:
            self.type(' ')
        elif control == DELETE:
            self.text = self.text[:-1]
            self.refresh()
        elif control == CLEAR:
            self.text = ''
            self.refresh()
        elif control == SUGGESTIONS:   # the title it offers, typed in full
            self.text = xbmc.getInfoLabel('Container(%d).ListItem.Label' % SUGGESTIONS)
            self.refresh()
            self.setFocusId(MATCHES)
        elif control == MATCHES:
            path = xbmc.getInfoLabel('Container(%d).ListItem.FolderPath' % MATCHES)
            if path:
                self.chosen = (path, xbmc.getInfoLabel('Container(%d).ListItem.Property(ItemType)' % MATCHES),
                               xbmc.getInfoLabel('Container(%d).ListItem.Property(id)' % MATCHES))
                self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()
        elif action.getId() in REMOTE_DIGITS:
            self.type(str(action.getId() - 58))

    def type(self, s):
        if len(self.text) < 60:
            self.text += s
        self.refresh()

    def mode(self, digits):
        self.digits = digits
        rows = DIGITS if digits else LETTERS
        for i in range(30):
            self.getControl(KEYS + i).setLabel(rows[i // 6][i % 6])
        HOME.setProperty('fmt_search_digits', 'true' if digits else '')

    def refresh(self):
        """The field now; the matches after a pause."""
        HOME.setProperty('fmt_search_text', self.text)
        if self.timer:
            self.timer.cancel()
        self.timer = threading.Timer(0 if not self.text else PAUSE, self.lookup, [self.text])
        self.timer.start()

    def lookup(self, asked):
        if asked != self.text:
            return   # typed on meanwhile: a newer one comes
        if asked.strip():
            try:   # in the TV's order: the server keeps the order of the ids it's asked for
                ids = ranked(asked.strip())
                url = '/Users/{userid}/Items?Ids=%s' % (','.join(ids) or 'none')
            except Exception as e:   # JellyCon signed out or the server slow: its own order
                xbmc.log('Free My TV search: %s' % e, xbmc.LOGWARNING)
                url = ('/Users/{userid}/Items?SearchTerm=%s&IncludeItemTypes=Movie,Series&Recursive=true&Limit=8'
                       % quote(asked.strip()))
            if asked != self.text:
                return
        elif self.popular:
            url = ('/Users/{userid}/items?ParentId=%s&SortBy=CommunityRating,PremiereDate&SortOrder=Descending&Limit=8'
                   % self.popular)
        else:   # no month's most watched on this server (the TV app makes it): the newest
            url = ('/Users/{userid}/items?IncludeItemTypes=Movie,Series&Recursive=true&SortBy=PremiereDate'
                   '&SortOrder=Descending&MaxPremiereDate=%s&Limit=8' % __import__('time').strftime('%Y-%m-%d'))
        HOME.setProperty('fmt_search_path', jellycon(url))


def popular_collection():
    """The "Lo más visto del mes" collection the TV app keeps on the server, if this server has one."""
    try:
        for o in jellyfin.call('/Users/{user}/Items?IncludeItemTypes=BoxSet&Recursive=true&EnableImages=false'
                               '&EnableUserData=false&SearchTerm=' + jellyfin.q('Lo más visto del mes')).get('Items', []):
            if o.get('Name', '').strip().lower() == 'lo más visto del mes':
                return o['Id']
    except Exception:
        pass
    return ''


def show(addon_path, popular):
    window = Search('script-freemytv-search.xml', addon_path, 'Default', '1080i')
    window.popular = popular or popular_collection()
    window.text = HOME.getProperty('fmt_search_last')   # the last search, kept until Kodi restarts
    HOME.setProperty('fmt_search_start', 'Lo más visto del mes' if window.popular else 'Novedades')
    HOME.clearProperty('fmt_search_chosen')
    import settings
    window.setProperty('backdrop', settings.backdrop())   # Home's focused title, blurred, behind it all the while
    window.doModal()
    chosen = window.chosen
    if HOME.getProperty('fmt_search_chosen'):   # a match picked: the window's own onclick (see the panel's)
        chosen = (HOME.getProperty('fmt_search_chosen'), HOME.getProperty('fmt_search_kind'), HOME.getProperty('fmt_search_id'))
    if window.timer:
        window.timer.cancel()
    HOME.setProperty('fmt_search_last', window.text.strip())
    del window
    for name in ('fmt_search_text', 'fmt_search_path', 'fmt_search_digits', 'fmt_search_start', 'fmt_search_chosen',
                 'fmt_search_kind', 'fmt_search_id'):
        HOME.clearProperty(name)
    if chosen:
        path, kind, item_id = chosen
        if kind == 'Person' and item_id:   # their page: what they did, their titles here (Back comes back through them)
            import title
            title.show(addon_path, '', 'Buscar', person_id=item_id)
        elif kind == 'Series' and item_id:   # its page, as on the home screen
            series.show(addon_path, item_id)
        elif kind == 'Movie' and item_id:
            import title
            title.show(addon_path, item_id, 'Buscar')
        else:
            xbmc.executebuiltin('PlayMedia("%s",noresume)' % path)   # JellyCon asks about resuming
