"""A series' page (script-freemytv-series.xml): its backdrop, title, facts and synopsis, Continue Watching and Watch
Later, the seasons as pills and each season's episodes as a row of stills, the focused one's synopsis below. OK on an
episode plays it through JellyCon.
"""
import threading

import xbmc
import xbmcgui

import held
import jellyfin
import later
import who

PLAY, LATER, SEASONS, EPISODES, CAST = 600, 601, 400, 500, 700
RATE, NOPE, LATER_TRAKT = 604, 605, 606   # Trakt's, through palantir-cine (cine.py): rating, Not interested, watchlist
BACK = (9, 10, 92)
MOVE = (1, 2)   # left, right: another season may have the focus


def woke(tags):
    """The woke tag's label and colour, as on the TV (Jellyfin.wokeLabel / wokeColor); none without the tag."""
    tag = next((t[5:].strip() for t in tags if t.lower().startswith('woke:')), None)
    if tag is None:
        return '', 'FF3A3A3C'
    colours = ['FF2FB24C', 'FF6CBF3A', 'FFD9C23A', 'FFE8A934', 'FFEC8A2F', 'FFE5352B', 'FFD0275A', 'FFB8278A',
               'FF8E2BB0', 'FF5E2AA8']
    try:
        level = int(''.join(c for c in tag.split('-')[0] if c.isdigit()))
    except ValueError:
        return 'Woke: ' + tag.replace('-', ' '), 'FF3A3A3C'
    return 'Woke ' + tag, 'FF0A84FF' if level == 0 else colours[min(9, level // 10)]


def minutes(ticks):
    m = int((ticks or 0) / 600000000)
    return '%d h %02d min' % (m // 60, m % 60) if m >= 60 else '%d min' % m if m else ''


class Series(xbmcgui.WindowXMLDialog):
    series_id = ''
    chosen = None   # the episode to play once the window is closed
    seasons = []
    season = -1
    next_up = None
    focus = None    # an episode to open on (Home's card of an episode): its season shown, it focused
    person = None   # (id, what they did) of someone in the cast picked: show opens their page, then this one again
    on_cast = False  # opened again from someone's page: the focus back on the cast
    addon_path = ''
    st = None   # the series' state in palantir-cine (cine.state)
    played = False

    def onInit(self):
        s = jellyfin.call('/Users/{user}/Items/%s?Fields=Genres,Overview,Tags,People' % self.series_id)
        self.setProperty('title', s.get('Name', ''))
        self.played = bool(s.get('UserData', {}).get('Played'))
        __import__('threading').Thread(target=self.trakt, daemon=True).start()
        facts = [str(s['ProductionYear'])] if s.get('ProductionYear') else []
        facts += s.get('Genres', [])[:2]
        if s.get('CommunityRating'):
            facts.append('★ %.1f' % s['CommunityRating'])
        if s.get('OfficialRating'):
            facts.append(s['OfficialRating'])
        self.setProperty('facts', '  ·  '.join(facts))
        label, colour = woke(s.get('Tags', []))
        self.setProperty('woke', label)
        self.setProperty('wokecolor', colour)
        self.setProperty('overview', s.get('Overview', ''))
        if s.get('BackdropImageTags'):
            self.setProperty('backdrop', jellyfin.image(self.series_id, 'Backdrop', 1920, s['BackdropImageTags'][0]))
        self.backdrop = self.getProperty('backdrop')
        self.refresh_later()
        import title   # (title imports this module)
        people = title.cast(s.get('People', []))
        self.getControl(CAST).addItems(people)

        self.seasons = jellyfin.call('/Shows/%s/Seasons?userId={user}&IsMissing=false' % self.series_id).get('Items', [])
        items = []
        for season in self.seasons:
            item = xbmcgui.ListItem(season.get('Name', ''))
            items.append(item)
        self.getControl(SEASONS).addItems(items)

        nxt = jellyfin.call('/Shows/NextUp?SeriesId=%s&UserId={user}&Limit=1' % self.series_id).get('Items', [])
        self.next_up = nxt[0] if nxt else None
        start = 0
        if self.next_up:
            ep = self.next_up
            self.setProperty('playlabel', 'Seguir viendo  ·  T%s:E%s' % (ep.get('ParentIndexNumber', '?'), ep.get('IndexNumber', '?')))
            start = next((i for i, x in enumerate(self.seasons) if x['Id'] == ep.get('SeasonId')), 0)
        else:   # not started: no button, an episode is chosen to start (the focus on the first)
            self.clearProperty('playlabel')
        if self.focus:
            start = next((i for i, x in enumerate(self.seasons) if x['Id'] == self.focus.get('SeasonId')), start)
        if self.seasons:
            self.getControl(SEASONS).selectItem(start)
            self.load(start)
        if self.on_cast and self.getControl(CAST).size():
            self.setFocusId(CAST)
        else:
            self.setFocusId(EPISODES if (self.focus or not self.next_up) and self.getControl(EPISODES).size() else PLAY)
        held.mark()

    def trakt(self):
        """Watch Later (Trakt's watchlist), Rate and Not interested, as palantir-cine says."""
        import cine
        st = self.st = cine.state(who.name(), self.series_id)
        linked = bool(st and st.get('trakt'))
        self.setProperty('canlater', 'true' if linked else '')
        self.setProperty('later', 'true' if linked and st.get('pendiente_trakt') else '')
        self.setProperty('canrate', 'true' if linked and not st.get('infantil') else '')
        self.setProperty('rated', 'true' if (st or {}).get('nota') else '')
        self.setProperty('cannope', 'true' if st and not self.played and not st.get('descartado') else '')

    def tell(self, said):
        xbmcgui.Dialog().notification('Free My TV', said, xbmcgui.NOTIFICATION_INFO, 3000)

    def refresh_later(self):
        inside = self.series_id in later.ids()
        self.setProperty('laterlabel', 'En Ver más tarde' if inside else 'Ver más tarde')

    def load(self, index):
        """The season's episodes, in the row (the next one to watch focused when it's this season)."""
        if index == self.season or index >= len(self.seasons):
            return
        self.season = index
        seasons = self.getControl(SEASONS)
        for i in range(seasons.size()):   # the season on show: a lighter pill
            seasons.getListItem(i).setProperty('current', 'true' if i == index else '')
        season = self.seasons[index]
        episodes = jellyfin.call('/Shows/%s/Episodes?userId={user}&seasonId=%s&IsMissing=false&IsVirtualUnAired=false'
                                 '&Fields=Overview' % (self.series_id, season['Id'])).get('Items', [])
        items, focus = [], 0
        for i, ep in enumerate(episodes):
            item = xbmcgui.ListItem('%s. %s' % (ep.get('IndexNumber', i + 1), ep.get('Name', '')))
            tags = ep.get('ImageTags', {})
            still = jellyfin.image(ep['Id'], 'Primary', 640, tags['Primary']) if tags.get('Primary') else self.backdrop
            item.setArt({'thumb': still})
            data = ep.get('UserData', {})
            done = 100 if data.get('Played') else int(data.get('PlayedPercentage') or 0)
            # after its length, as the TV's: watched, or what's left of one started
            left = int((ep.get('RunTimeTicks') or 0) * (100 - done) / 100 / 600000000 + 0.999) if 0 < done < 100 else 0
            state = 'visto' if data.get('Played') else 'quedan %d min' % left if left else ''
            item.setProperties({'id': ep['Id'], 'overview': ep.get('Overview', ''), 'runtime': minutes(ep.get('RunTimeTicks')),
                                'progress': str(min(10, (done + 5) // 10)) if 0 < done < 100 else '', 'state': state})
            items.append(item)
            if (self.focus or self.next_up) and ep['Id'] == (self.focus or self.next_up)['Id']:
                focus = i
        control = self.getControl(EPISODES)
        control.reset()
        control.addItems(items)
        if items:
            control.selectItem(focus)

    def onAction(self, action):
        if action.getId() in BACK and self.getFocusId() == CAST:
            self.setFocusId(EPISODES)   # from the cast: back to the episodes first, as the title page
        elif action.getId() in BACK:
            self.close()
        elif action.getId() in MOVE and self.getFocusId() == SEASONS:
            self.load(self.getControl(SEASONS).getSelectedPosition())

    def onClick(self, control):
        if held.repeat():   # OK still held (a TV's remote through CEC)
            self.held = True
            self.close()
            return
        if control == CAST:
            item = self.getControl(CAST).getSelectedItem()
            if item and item.getProperty('id'):
                self.person = (item.getProperty('id'), item.getProperty('role'))
                self.close()
        elif control == SEASONS:
            self.load(self.getControl(SEASONS).getSelectedPosition())
            self.setFocusId(EPISODES)
        elif control == EPISODES:
            item = self.getControl(EPISODES).getSelectedItem()
            if item:
                self.chosen = item.getProperty('id')
                self.close()
        elif control == PLAY:
            if self.next_up:
                self.chosen = self.next_up['Id']
                self.close()
        elif control == RATE:
            import actions
            actions.rate(self.addon_path, {'Id': self.series_id, 'Name': self.getProperty('title'), 'Type': 'Series'},
                         self.st)
            self.trakt()
        elif control in (NOPE, LATER_TRAKT):
            import cine
            user, out = who.name(), bool((self.st or {}).get('pendiente_trakt'))
            try:
                if control == NOPE:
                    cine.call('no_me_interesa', usuario=user, titulo_o_id=self.series_id)
                    self.tell('No te la volverá a recomendar: ' + self.getProperty('title'))
                else:
                    cine.call('pendiente', usuario=user, titulo_o_id=self.series_id, quitar=out)
                    self.tell(('Quitada de Ver más tarde: ' if out else 'Añadida a Ver más tarde (Trakt): ')
                              + self.getProperty('title'))
            except Exception as e:
                xbmcgui.Dialog().notification('Free My TV', 'No se pudo: %s' % e, xbmcgui.NOTIFICATION_WARNING, 5000)
            self.trakt()
        elif control == LATER:
            added = later.toggle(self.series_id, self.getProperty('title'))
            self.setProperty('laterlabel', 'En Ver más tarde' if added else 'Ver más tarde')


def show(addon_path, series_id, episode=None):
    on_cast = False
    while True:
        window = Series('script-freemytv-series.xml', addon_path, 'Default', '1080i')
        window.series_id, window.focus, window.on_cast = series_id, episode, on_cast
        window.addon_path = addon_path
        window.doModal()
        chosen, person, name = window.chosen, window.person, window.getProperty('title')
        hold = getattr(window, 'held', False)
        del window
        if hold and not on_cast:   # held on Home's poster: its quick actions instead (the episode's, from one)
            import actions
            actions.show(addon_path, episode['Id'] if episode else series_id)
            return False
        if not person:
            break
        import title   # their page (its titles open from it); Back comes back to this series
        if title.show(addon_path, '', name + '  ·  Reparto', person_id=person[0], role=person[1]):
            return True
        on_cast = True
    if chosen:
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % jellyfin.play(chosen))   # JellyCon asks about resuming
    return chosen   # the filters reopen only when nothing plays
