"""Jellyfin, asked directly with the session JellyCon keeps on this box (its server, user and token): the search
ranking, the series page, Watch Later and the tab picker need more than JellyCon's folders give. The token never goes
to the log. JellyCon still plays everything (play() hands it the item), so its playback settings and reporting stay.
"""
import json
import os
import re
import urllib.request
from urllib.parse import quote

import xbmcvfs

import who

FOLDER = 'special://profile/addon_data/plugin.video.jellycon/'


def session():
    """JellyCon's server address, user id and token, or an exception when it isn't signed in."""
    folder = xbmcvfs.translatePath(FOLDER)
    with open(os.path.join(folder, 'settings.xml'), encoding='utf-8') as f:
        s = f.read()
    server = re.search(r'<setting id="server_address"[^>]*>([^<]*)<', s).group(1).rstrip('/')
    with open(os.path.join(folder, 'auth.json'), encoding='utf-8') as f:
        users = json.load(f)
    # The user JellyCon is signed in as (it keeps every user that ever signed in on this device: the profiles)
    user = users.get(who.name()) or next(iter(users.values()))
    return server, user['user_id'], user['token']


# A child's profile: its user may only see what's tagged so on the server (its policy's allowed tags); its month's most
# watched is the server's own collection for children (kept by the server), as on the TV (Jellyfin.child)
CHILD_TAG, KIDS_POPULAR = 'perfil:infantil', 'lo más visto del mes · infantil'


def child():
    """Whether JellyCon's user is a child's profile; asked once per user (Window(home).Property(fmt_child))."""
    import xbmcgui
    home = xbmcgui.Window(10000)
    user = session()[1]
    kept = home.getProperty('fmt_child')
    if kept.startswith(user + '|'):
        return kept.endswith('|1')
    try:
        allowed = (call('/Users/{user}').get('Policy') or {}).get('AllowedTags') or []
    except Exception:   # the server away: as an adult's, asked again next time
        return False
    kid = any(t.strip().lower() == CHILD_TAG for t in allowed)
    home.setProperty('fmt_child', '%s|%d' % (user, kid))
    return kid


def kids_popular():
    """The children's month's most watched collection's id, '' when this user can't see it."""
    for o in call('/Users/{user}/Items?IncludeItemTypes=BoxSet&Recursive=true&EnableImages=false&EnableUserData=false'
                  ).get('Items', []):
        if o.get('Name', '').strip().lower() == KIDS_POPULAR:
            return o['Id']
    return ''


def call(path, method='GET', body=None):
    """The server's answer to a request (JSON), {} for an empty one. {user} in the path is the user id."""
    server, user, token = session()
    request = urllib.request.Request(server + path.replace('{user}', user), method=method,
                                     data=None if body is None else json.dumps(body).encode(),
                                     headers={'Authorization': 'MediaBrowser Client="Free My TV", Device="Kodi", '
                                                               'DeviceId="freemytv-kodi", Version="1.0", Token="%s"' % token,
                                              'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=15) as r:
        data = r.read()
    return json.loads(data) if data else {}


def image(item_id, kind='Primary', width=480, tag=None):
    """An item's image address (Jellyfin serves images without a token)."""
    server = session()[0]
    return '%s/Items/%s/Images/%s?maxWidth=%d%s' % (server, item_id, kind, width, '&tag=' + tag if tag else '')


def play(item_id):
    """JellyCon's address that plays an item (it picks the version, resumes, reports progress)."""
    return 'plugin://plugin.video.jellycon/?item_id=%s&mode=PLAY' % item_id


def q(s):
    return quote(s, safe='')


# MARK: - Watch Later (the TV's playlist: Jellyfin.toggleWatchLater on Android)

LATER_NAMES = ('ver más tarde', 'watch later', 'assistir depois', 'später ansehen', 'смотреть позже')


def later_list():
    """The "Watch Later" playlist's id (any of the app's languages), or None."""
    for o in call('/Users/{user}/Items?IncludeItemTypes=Playlist&Recursive=true').get('Items', []):
        if o.get('Name', '').strip().lower() in LATER_NAMES:
            return o['Id']
    return None


def own_later():
    """Their Watch Later, made empty when they have none yet (a new profile's tab, settings.adapted)."""
    return later_list() or call('/Playlists', 'POST', {'Name': 'Ver más tarde', 'UserId': session()[1], 'MediaType': 'Video',
                                                       'Ids': []}).get('Id')


def later_ids():
    """The titles in Watch Later."""
    playlist = later_list()
    if not playlist:
        return []
    return [o['Id'] for o in call('/Playlists/%s/Items?UserId={user}' % playlist).get('Items', [])]


def toggle_later(item_id):
    """Adds the title to Watch Later, or takes it out; True when it was added. The playlist is made the first time.
    Not a series: a Jellyfin playlist turns a series into all of its episodes (One Piece: 2,300 entries)."""
    if call('/Users/{user}/Items/%s' % item_id).get('Type') == 'Series':
        raise ValueError('una lista de Jellyfin no admite series enteras (las parte en episodios)')
    playlist = later_list()
    if not playlist:
        call('/Playlists', 'POST', {'Name': 'Ver más tarde', 'UserId': session()[1], 'MediaType': 'Video', 'Ids': [item_id]})
        return True
    for o in call('/Playlists/%s/Items?UserId={user}' % playlist).get('Items', []):
        if o.get('Id') == item_id:
            call('/Playlists/%s/Items?EntryIds=%s' % (playlist, q(o['PlaylistItemId'])), 'DELETE')
            return False
    call('/Playlists/%s/Items?Ids=%s&UserId={user}' % (playlist, item_id), 'POST')
    return True
