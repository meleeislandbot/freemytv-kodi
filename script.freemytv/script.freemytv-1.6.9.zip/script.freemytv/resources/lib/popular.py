"""The month's most watched in Trakt's order, for its tab's first order: the TV app keeps the titles in a Jellyfin
collection ("Lo más visto del mes", Jellyfin.syncPopular), which Jellyfin sorts by release date, so the service asks
Trakt for the ranking once a day as the TV does (Recs.findPopular: movies and shows in turn, no animated shows) and
keeps the collection's ids in that order in popular-<collection>.json; Jellyfin returns titles asked for by id in that
order. A child's profile shows the server's collection for children (settings.kids_top), ordered by Trakt's month's most
watched animation for their age, the shows' cartoons kept (as the TV's Recs.findKidsPopular).
The Trakt Client ID is the one in config.properties (install.py copies it to trakt.txt); it never goes to the log."""
import json
import os
import time

import xbmc
import xbmcvfs

FOLDER = 'special://profile/addon_data/script.freemytv/'


def path(name):
    return os.path.join(xbmcvfs.translatePath(FOLDER), name)


def ids(collection):
    """The collection's ids, most watched first, as last worked out; [] when there's no ranking yet."""
    try:
        with open(path('popular-%s.json' % collection), encoding='utf-8') as f:
            kept = json.load(f)
        return kept['ids'] if kept.get('collection') == collection else []
    except (OSError, ValueError, KeyError):
        return []


# Trakt's filters for the children's: animation rated for them (the server's collection, kept the same way)
KIDS = {'movies': '&genres=animation&certifications=g,pg', 'shows': '&genres=animation&certifications=tv-y,tv-y7,tv-g,tv-pg'}


def trakt(kind, key, filters=''):
    import urllib.request   # here: settings.publish reads ids() at start, when urllib takes seconds to load
    request = urllib.request.Request('https://api.trakt.tv/%s/watched/monthly?limit=100&extended=full%s' % (kind, filters),
                                     headers={'trakt-api-version': '2', 'trakt-api-key': key,
                                              'Content-Type': 'application/json', 'User-Agent': 'FreeMyTV'})
    with urllib.request.urlopen(request, timeout=20) as r:
        return [o.get(kind[:-1], {}) for o in json.load(r)]


def ranking(key, kids=False):
    """[('movie' or 'show', TMDB id)] in Trakt's order: movies and shows in turn, no anime or cartoons among the shows
    (a child's: only animation for their age, cartoons and all)."""
    if kids:
        movies, shows = trakt('movies', key, KIDS['movies']), trakt('shows', key, KIDS['shows'])
    else:
        movies = trakt('movies', key)
        shows = [o for o in trakt('shows', key) if not {'animation', 'anime'} & set(o.get('genres') or [])]
    out = []
    for i in range(max(len(movies), len(shows))):
        for kind, row in (('movie', movies), ('show', shows)):
            if i < len(row) and (row[i].get('ids') or {}).get('tmdb'):
                out.append((kind, str(row[i]['ids']['tmdb'])))
    return out


def stale(collection):
    """True when the TV changed the collection's titles since the order was worked out (it does, once a day)."""
    if not os.path.exists(path('trakt.txt')):
        return False   # no Client ID here: no order to work out
    try:
        import jellyfin
        items = jellyfin.call('/Users/{user}/Items?ParentId=%s&EnableImages=false&EnableUserData=false' % collection)
    except Exception:   # the server away: tried again later
        return False
    return {o['Id'] for o in items.get('Items', [])} != set(ids(collection))


def refresh(collection, force=False):
    """Works the order out again if it's from another day or collection (or forced); True when it changed."""
    try:
        with open(path('popular-%s.json' % collection), encoding='utf-8') as f:
            kept = json.load(f)
        if not force and kept.get('day') == time.strftime('%Y-%m-%d') and kept.get('collection') == collection:
            return False
    except (OSError, ValueError):
        kept = {}
    try:
        with open(path('trakt.txt'), encoding='utf-8') as f:
            key = f.read().strip()
    except OSError:
        return False   # no Client ID on this box: the tab starts best rated
    if not key or not collection:
        return False
    try:
        import jellyfin
        import settings
        rank = {title: n for n, title in enumerate(ranking(key, kids=collection == settings.kids_top()))}
        items = jellyfin.call('/Users/{user}/Items?ParentId=%s&Fields=ProviderIds&EnableImages=false'
                              '&EnableUserData=false&SortBy=PremiereDate&SortOrder=Descending' % collection).get('Items', [])
    except Exception as e:
        xbmc.log('Free My TV, most watched: %s' % e, xbmc.LOGWARNING)
        return False
    place = lambda o: rank.get(('show' if o.get('Type') == 'Series' else 'movie',
                                str((o.get('ProviderIds') or {}).get('Tmdb', ''))), len(rank))
    order = [o['Id'] for o in sorted(items, key=place)]   # stable: the ones Trakt no longer lists, newest first, last
    with open(path('popular-%s.json' % collection), 'w', encoding='utf-8') as f:
        json.dump({'day': time.strftime('%Y-%m-%d'), 'collection': collection, 'ids': order}, f)
    xbmc.log('Free My TV, most watched: %d in Trakt\'s order' % len(order), xbmc.LOGINFO)
    return order != kept.get('ids')
