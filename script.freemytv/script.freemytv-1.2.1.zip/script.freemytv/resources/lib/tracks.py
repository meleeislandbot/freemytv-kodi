"""The player's two buttons of ours (VideoOSD.xml, install.py's osd_window): the audio track and the version.

RunScript(script.freemytv,audio): the playing file's audio tracks, the current one chosen; another switches to it.
RunScript(script.freemytv,version): the title's versions on Jellyfin (JellyCon plays the best without asking,
jellycon_fixes); another plays that one from the same point, through JellyCon. The service's Watcher keeps the playing
title's versions in Window(home).Property(fmt_versions), so the button shows only when there are several.
"""
import json
import threading

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
NOW = 'plugin.video.jellycon-now_playing'   # what JellyCon is playing: its item and version (source) ids
CODECS = {'truehd': 'TrueHD', 'eac3': 'Dolby Digital Plus', 'ac3': 'Dolby Digital', 'dtshd_ma': 'DTS-HD MA',
          'dtshd_hra': 'DTS-HD', 'dca': 'DTS', 'dts': 'DTS', 'aac': 'AAC', 'flac': 'FLAC', 'opus': 'Opus',
          'mp3': 'MP3', 'pcm': 'PCM', 'vorbis': 'Vorbis'}

LANGUAGES = {'spa': 'Español', 'es': 'Español', 'cat': 'Catalán', 'eng': 'Inglés', 'en': 'Inglés', 'fre': 'Francés',
             'fra': 'Francés', 'ger': 'Alemán', 'deu': 'Alemán', 'ita': 'Italiano', 'por': 'Portugués', 'jpn': 'Japonés',
             'kor': 'Coreano', 'chi': 'Chino', 'zho': 'Chino', 'rus': 'Ruso', 'und': 'Sin idioma'}


def rpc(method, **params):
    answer = xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}))
    return json.loads(answer).get('result') or {}


def channels(n):
    return {1: 'mono', 2: '2.0', 6: '5.1', 7: '6.1', 8: '7.1'}.get(n or 0, '%d canales' % n if n else '')


def audio():
    player = next((p['playerid'] for p in rpc('Player.GetActivePlayers') if p.get('type') == 'video'), None)
    if player is None:
        return
    now = rpc('Player.GetProperties', playerid=player, properties=['audiostreams', 'currentaudiostream'])
    streams = now.get('audiostreams') or []
    if not streams:
        xbmcgui.Dialog().notification('Audio', 'Este vídeo no tiene pistas de audio', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    current = (now.get('currentaudiostream') or {}).get('index')
    rows = []
    for s in streams:
        code = (s.get('language') or '').lower()
        language = LANGUAGES.get(code) or (xbmc.convertLanguage(code, xbmc.ENGLISH_NAME) if code else '')
        details = [s.get('name') if s.get('name') and s.get('name') != language else '',
                   CODECS.get(s.get('codec'), (s.get('codec') or '').upper()), channels(s.get('channels'))]
        rows.append(xbmcgui.ListItem(language or 'Pista %d' % (s['index'] + 1), '  ·  '.join(t for t in details if t)))
    pick = xbmcgui.Dialog().select('Audio', rows, preselect=next((i for i, s in enumerate(streams) if s['index'] == current), -1),
                                   useDetails=True)
    if pick >= 0 and streams[pick]['index'] != current:
        rpc('Player.SetAudioStream', playerid=player, stream=streams[pick]['index'])


def describe(source):
    """A version's line under its name: picture, video codec, audio and size, from the server's data."""
    video = next((s for s in source.get('MediaStreams') or [] if s.get('Type') == 'Video'), {})
    sound = next((s for s in source.get('MediaStreams') or [] if s.get('Type') == 'Audio'), {})
    width = video.get('Width') or 0
    picture = '4K' if width >= 3200 else '1080p' if width >= 1700 else '720p' if width >= 1200 else '%dp' % video['Height'] if video.get('Height') else ''
    hdr = video.get('VideoRangeType') or ''
    hdr = 'Dolby Vision' if 'DOVI' in hdr else 'HDR10+' if 'HDR10Plus' in hdr else 'HDR' if hdr not in ('', 'SDR', 'Unknown') else ''
    size = '%.1f GB' % (source['Size'] / 1e9) if source.get('Size') else ''
    parts = [picture, hdr, (video.get('Codec') or '').upper(), CODECS.get(sound.get('Codec'), (sound.get('Codec') or '').upper()),
             size.replace('.', ',')]
    return '  ·  '.join(p for p in parts if p)


def sources(item):
    import jellyfin
    return jellyfin.call('/Users/{user}/Items/%s?Fields=MediaSources' % item).get('MediaSources') or []


def version():
    now = json.loads(HOME.getProperty(NOW) or '{}')
    item, playing = now.get('item_id'), now.get('source_id')
    if not item:
        return
    try:
        found = json.loads(HOME.getProperty('fmt_versions') or '[]') or sources(item)
    except Exception as e:
        xbmcgui.Dialog().notification('Versión', 'Jellyfin no responde: %s' % e, xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    if len(found) < 2:
        xbmcgui.Dialog().notification('Versión', 'Este título solo tiene una versión', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    rows = [xbmcgui.ListItem(s.get('Name') or 'Versión %d' % (n + 1), describe(s)) for n, s in enumerate(found)]
    pick = xbmcgui.Dialog().select('Versión', rows, preselect=next((i for i, s in enumerate(found) if s.get('Id') == playing), -1),
                                   useDetails=True)
    if pick < 0 or found[pick].get('Id') == playing:
        return
    at = int(xbmc.Player().getTime() * 10000000) if xbmc.Player().isPlayingVideo() else -1   # JellyCon's ticks
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.jellycon/?item_id=%s&mode=PLAY&media_source_id=%s&auto_resume=%d")'
                        % (item, found[pick]['Id'], at))


class Watcher(xbmc.Player):
    """For the version button: the playing title's versions, asked once it starts (only JellyCon's titles)."""
    def onAVStarted(self):
        HOME.clearProperty('fmt_versions')
        item = json.loads(HOME.getProperty(NOW) or '{}').get('item_id')
        if item:
            threading.Thread(target=self.ask, args=(item,), daemon=True).start()

    def ask(self, item):
        try:
            found = [{k: s.get(k) for k in ('Id', 'Name', 'Size', 'MediaStreams')} for s in sources(item)]
        except Exception as e:   # the server away: the button stays hidden
            xbmc.log('Free My TV, versions: %s' % e, xbmc.LOGWARNING)
            return
        if json.loads(HOME.getProperty(NOW) or '{}').get('item_id') == item:   # still the one playing
            HOME.setProperty('fmt_versions', json.dumps(found) if len(found) > 1 else '')

    def onPlayBackStopped(self):
        HOME.clearProperty('fmt_versions')

    onPlayBackEnded = onPlayBackStopped
