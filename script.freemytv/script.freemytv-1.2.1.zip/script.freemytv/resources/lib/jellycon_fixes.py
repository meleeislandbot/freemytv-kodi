"""JellyCon's changes for Free My TV, put in by the add-on's service (at start and every few minutes, so they come back
after JellyCon updates itself) and by kodi/install.py on the Ugoos (python3 - <JellyCon's lib folder> <its settings.xml>):

- it reads tags from "TagItems" (Emby's), which Jellyfin doesn't send: it sends "Tags" (the woke colours need them);
- the skin gets the item's id (series pages, Watch Later) and whether it's in Watch Later (later.py keeps the ids in
  Window(home).Property(fmt_later));
- its menu (hold OK), which replaces Kodi's so add-ons' entries never show, gets Watch Later first, for a movie;
- a title with several versions plays the best for this box (best.py) without asking; JellyCon asks only when none
  answers;
- its resume question in Spanish (ResumeDialog.xml).

Every line of ours says "Free My TV": each pass takes them all out and puts them back, so nothing is doubled, and a file
is written only when that changes it. A change whose anchor JellyCon no longer has is logged and left out, and a file
that wouldn't compile is never written: JellyCon keeps working as it is.
"""
import os
import re
import sys

TAGS_FIX = """    if not item_details.tags and item.get("Tags", []):   # Free My TV: Jellyfin sends Tags
        item_details.tags = list(item.get("Tags"))   # Free My TV
"""
ID_FIX = """    item_properties["id"] = item_details.id   # Free My TV: the item's id, for the skin
    if item_details.id and item_details.id in __import__("xbmcgui").Window(10000).getProperty("fmt_later"):   # Free My TV: in Watch Later
        item_properties["later"] = "true"   # Free My TV
"""
MENU_FIX = """    if result["Type"] == "Movie":   # Free My TV: Watch Later, first
        li = xbmcgui.ListItem("Quitar de Ver más tarde" if item_id in xbmcgui.Window(10000).getProperty("fmt_later") else "Ver más tarde", offscreen=True)   # Free My TV
        li.setProperty("menu_id", "fmt_later")   # Free My TV
        action_items.append(li)   # Free My TV
"""
MENU_ACTION = """    if selected_action == "fmt_later":   # Free My TV
        xbmc.executebuiltin("RunScript(script.freemytv,later,%s)" % item_id)   # Free My TV
"""
BEST_FIX = """        __import__("sys").path.append(__import__("xbmcvfs").translatePath("special://home/addons/script.freemytv/resources/lib"))   # Free My TV
        selected_media_source = __import__("best").best(media_sources)   # Free My TV: the best version, without asking
    if selected_media_source is None and len(media_sources) > 1 and media_source_id == "":   # Free My TV: none answered
"""
RESUME_FIX = '            resume_dialog.setResumeTime("Seguir desde " + display_time)   # Free My TV\n'
# Lines earlier installs left without the mark
OLD_LINES = ('        item_details.tags = list(item.get("Tags"))', '        item_properties["later"] = "true"')

# file: [(anchor, our lines, before or after it)]
FIXES = {'item_functions.py': [('    # set the item name\n', TAGS_FIX, 'before'),
                               ('    item_properties["ItemType"] = item_details.item_type\n', ID_FIX, 'after')],
         'play_utils.py': [('    elif len(media_sources) > 1:\n', BEST_FIX, 'after'),
                           ('            resume_dialog.setResumeTime("Resume from " + display_time)\n', RESUME_FIX, 'after')],
         'functions.py': [('    action_items = []\n', MENU_FIX, 'after'),
                          ('    if selected_action == "play":\n', MENU_ACTION, 'before')]}


def patch(folder, log=print):
    """Puts the changes in JellyCon's resources/lib folder; the names of the files written (none when they were in)."""
    written = []
    for name, file_fixes in FIXES.items():
        path = os.path.join(folder, name)
        try:
            with open(path, encoding='utf-8') as f:
                before = f.read()
        except OSError as e:
            log('JellyCon has no %s: left as it is (%s)' % (name, e))
            continue
        s = '\n'.join(l for l in before.split('\n') if 'Free My TV' not in l and l not in OLD_LINES)
        for anchor, fix, where in file_fixes:
            if anchor in s:
                s = s.replace(anchor, fix + anchor if where == 'before' else anchor + fix, 1)
            else:
                log('JellyCon changed: %s no longer has "%s"; that change is left out' % (name, anchor.strip()))
        if s == before:
            continue
        try:
            compile(s, path, 'exec')
        except SyntaxError as e:
            log('JellyCon\'s %s would not compile with the changes (%s): left as it is' % (name, e))
            continue
        with open(path + '.fmt', 'w', encoding='utf-8') as f:
            f.write(s)
        os.replace(path + '.fmt', path)   # whole: JellyCon may be importing it right now
        written.append(name)
    return written


def no_image_cache(path):
    """JellyCon's «cache images on screensaver» off in its settings file (its default is on): each time Kodi's
    screensaver came on it asked the server for the whole library and ran it out of memory. True when it was written."""
    try:
        with open(path, encoding='utf-8') as f:
            before = f.read()
    except OSError:
        return False
    line = '<setting id="cacheImagesOnScreenSaver">false</setting>'
    if re.search(r'<setting id="cacheImagesOnScreenSaver"[^>]*>', before):
        s = re.sub(r'<setting id="cacheImagesOnScreenSaver"[^>]*>[^<]*</setting>|<setting id="cacheImagesOnScreenSaver"[^>]*/>',
                   line, before)
    else:
        s = before.replace('</settings>', '    ' + line + '\n</settings>')
    if s == before:
        return False
    with open(path, 'w', encoding='utf-8') as f:
        f.write(s)
    return True


def in_kodi():
    """The service's pass. The listings take the changes at once (JellyCon runs them anew each time); its menu and its
    player live in its own service, which loaded the files at start: they take them after Kodi restarts, so the person
    is told once when those were written."""
    import xbmc
    import xbmcaddon
    try:
        folder = os.path.join(xbmcaddon.Addon('plugin.video.jellycon').getAddonInfo('path'), 'resources', 'lib')
    except RuntimeError:   # no JellyCon
        return
    written = patch(folder, lambda m: xbmc.log('Free My TV: ' + m, xbmc.LOGWARNING))
    if written:
        xbmc.log('Free My TV: JellyCon changed (%s)' % ', '.join(written), xbmc.LOGINFO)
    if set(written) & {'functions.py', 'play_utils.py'}:
        import xbmcgui
        xbmcgui.Dialog().notification('Free My TV', 'Reinicia Kodi para terminar de ajustar JellyCon',
                                      xbmcgui.NOTIFICATION_INFO, 10000)


if __name__ == '__main__':   # kodi/install.py, on the Ugoos: python3 - <JellyCon's lib folder> [<its settings.xml>]
    if os.path.isdir(sys.argv[1]):
        patch(sys.argv[1])
    if len(sys.argv) > 2:
        no_image_cache(sys.argv[2])
