"""Kodi's context menu (hold OK on a poster): "Ver más tarde" for a Jellyfin movie or series, as holding OK does on the
TV. It adds the title to the shared playlist, or takes it out.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

import later  # noqa: E402

item = sys.listitem
item_id = item.getProperty('id')
if item_id:
    later.toggle(item_id, item.getLabel())
