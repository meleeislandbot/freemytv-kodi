"""A movie's page (script-freemytv-title.xml), as the TV's TitleActivity: its backdrop, what it is, the synopsis and
Watch, Trailer, Watch Later and Watched; below, the cast and More like this (the server's Similar, as Home's posters).
OK on one of those opens its page (a series, series.py's); Back goes back to the title before it.
"""
import re
import threading
import time
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcvfs

import jellyfin
import later
import panel
import series
import settings
import ttf

PLAY, TRAILER, LATER, WATCHED, CAST, SIMILAR = 600, 601, 602, 603, 700, 800
BACK = (9, 10, 92)
HOME = xbmcgui.Window(10000)
YOUTUBE = re.compile(r'(?:v=|youtu\.be/|/embed/)([A-Za-z0-9_-]{11})')
CAST_MAX = 14
PLOT_W, PLOT_LINES, PLOT_SIZE = 1440, 4, 24   # the synopsis' textbox (install.py's title_window: fmt_plotsmall)


def ink(colour):
    """Dark text on the light woke colours, white on blue, the reds and gray (the TV's Jellyfin.wokeInk)."""
    r, g, b = (int(colour[i:i + 2], 16) for i in (2, 4, 6))
    return 'FF1C1C1E' if 0.299 * r + 0.587 * g + 0.114 * b > 150 else 'FFFFFFFF'


def initials(name):
    return ''.join(w[0].upper() for w in name.split()[:2] if w)


class Title(xbmcgui.WindowXMLDialog):
    item_id = ''
    back_to = ''
    chosen = None   # what to play once the window is closed: the movie, or its trailer
    played = False
    open = True
    blurred = ''

    def onInit(self):
        o = jellyfin.call('/Users/{user}/Items/%s?Fields=Genres,Overview,Tags,People,RemoteTrailers' % self.item_id)
        self.name = o.get('Name', '')
        self.setProperty('from', self.back_to)
        self.setProperty('title', self.name)
        kind = ['Película'] + ([str(o['ProductionYear'])] if o.get('ProductionYear') else [])
        kind += [series.minutes(o.get('RunTimeTicks'))] if o.get('RunTimeTicks') else []
        self.setProperty('kind', '  ·  '.join(kind))
        self.setProperty('facts', '  ·  '.join(kind + ([' / '.join(o['Genres'])] if o.get('Genres') else [])))
        label, colour = series.woke(o.get('Tags', []))
        self.setProperty('woke', label)
        self.setProperty('wokecolor', colour)
        self.setProperty('wokeink', ink(colour))
        if o.get('CommunityRating'):
            self.setProperty('rating', '★ %s' % ('%.1f' % o['CommunityRating']).replace('.', ','))
        self.setProperty('age', o.get('OfficialRating', ''))
        self.setProperty('overview', o.get('Overview', ''))
        threading.Thread(target=self.edges, args=(o.get('Overview', ''),), daemon=True).start()
        if o.get('BackdropImageTags'):
            self.setProperty('backdrop', jellyfin.image(self.item_id, 'Backdrop', 1920, o['BackdropImageTags'][0]))
            # for a person's page opened from here: blurred by the server, as on the TV
            self.blurred = jellyfin.image(self.item_id, 'Backdrop', 960, o['BackdropImageTags'][0]) + '&blur=40'
        trailer = next((m.group(1) for t in o.get('RemoteTrailers', []) for m in [YOUTUBE.search(t.get('Url', ''))] if m), '')
        if trailer and xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            self.setProperty('trailer', trailer)
        self.played = bool(o.get('UserData', {}).get('Played'))
        self.setProperty('watched', 'true' if self.played else '')
        self.setProperty('later', 'true' if self.item_id in later.ids() else '')

        # The actors as the server lists them (the leads first), then who directed it
        actors, directors = [], []
        for p in o.get('People', []):
            if p.get('Type') in ('Actor', 'GuestStar') and len(actors) < CAST_MAX:
                actors.append((p, p.get('Role', '')))
            elif p.get('Type') == 'Director' and len(directors) < 2:
                directors.append((p, 'Dirección'))
        items = []
        for p, role in actors + directors:
            item = xbmcgui.ListItem(p.get('Name', ''), role)
            if p.get('PrimaryImageTag'):
                item.setArt({'thumb': jellyfin.image(p['Id'], 'Primary', 360, p['PrimaryImageTag'])})
            item.setProperty('initials', initials(p.get('Name', '')))
            item.setProperty('id', p.get('Id', ''))
            item.setProperty('role', 'Actor' if role != 'Dirección' else role)
            items.append(item)
        self.getControl(CAST).addItems(items)
        if items:
            self.setProperty('below', 'true')
        threading.Thread(target=self.similar, daemon=True).start()
        self.setFocusId(PLAY)

    def similar(self):
        """More like this: the server's Similar, as JellyCon's items by id (Home's posters, woke colours and marks)."""
        try:
            ids = [i['Id'] for i in jellyfin.call('/Items/%s/Similar?UserId={user}&Limit=12&EnableImages=false'
                                                  '&EnableUserData=false' % self.item_id).get('Items', [])]
        except Exception as e:
            xbmc.log('Free My TV, similar: %s' % e, xbmc.LOGWARNING)
            return
        if ids:
            self.setProperty('similar', 'plugin://plugin.video.jellycon/?url=' + quote(
                '/Users/{userid}/Items?Ids=' + ','.join(ids) + settings.FIELDS, safe='/')
                + '&mode=GET_CONTENT&media_type=Playlist&sort=none')
            self.setProperty('below', 'true')

    def edges(self, text):
        """The synopsis' fades while it rises (the textbox's autoscroll, timed as Home's: panel.edges)."""
        try:
            ems = ttf.advances(xbmcvfs.translatePath('special://skin/fonts/') + panel.PLOT_FONT)
        except (OSError, ValueError, KeyError, TypeError) as e:
            xbmc.log('Free My TV, title: %s' % e, xbmc.LOGWARNING)
            return
        extra = max(0, panel.lines(text, ems, PLOT_W, PLOT_SIZE) - PLOT_LINES)
        xbmc.log('Free My TV, title: synopsis %d lines past four' % extra, xbmc.LOGDEBUG)
        if not extra:
            return
        since, monitor = time.time(), xbmc.Monitor()
        while self.open and not monitor.waitForAbort(0.1):
            more, top = panel.edges(time.time() - since, extra)
            if bool(self.getProperty('plot_more')) != more:
                self.setProperty('plot_more', 'true' if more else '')
            if bool(self.getProperty('plot_top')) != top:
                self.setProperty('plot_top', 'true' if top else '')

    def close(self):
        self.open = False
        super().close()

    def onAction(self, action):
        picked = HOME.getProperty('fmt_title_next') or HOME.getProperty('fmt_title_person')
        if action.getId() in BACK and self.getFocusId() in (CAST, SIMILAR) and not picked:
            self.setFocusId(PLAY)   # from the rows below: back to the top first, as on the TV
        elif action.getId() in BACK:
            self.close()

    def onClick(self, control):
        if control == CAST:   # the person's page, opened by show once this one is closed
            item = self.getControl(CAST).getSelectedItem()
            if item and item.getProperty('id'):
                HOME.setProperty('fmt_title_person', item.getProperty('id'))
                HOME.setProperty('fmt_title_role', item.getProperty('role'))
                self.close()
        elif control == PLAY:
            self.chosen = jellyfin.play(self.item_id)
            self.close()
        elif control == TRAILER and self.getProperty('trailer'):
            self.chosen = 'plugin://plugin.video.youtube/play/?video_id=' + self.getProperty('trailer')
            self.close()
        elif control == LATER:
            added = later.toggle(self.item_id, self.name)
            self.setProperty('later', 'true' if added else '')
        elif control == WATCHED:
            want = not self.played
            try:
                jellyfin.call('/Users/{user}/PlayedItems/%s' % self.item_id, 'POST' if want else 'DELETE')
                self.played = want
                self.setProperty('status', 'Marcada como vista' if want else 'Marcada como no vista')
            except Exception as e:
                xbmc.log('Free My TV, watched: %s' % e, xbmc.LOGWARNING)
                self.setProperty('status', 'No se pudo marcar: %s' % e)
            self.setProperty('watched', 'true' if self.played else '')


def show(addon_path, item_id, back_to=''):
    """The movie's page; OK on More like this or on someone in the cast opens that page, and Back comes back to this
    one. True when something plays (the filters and the search reopen only when nothing does)."""
    import person
    stack = [('title', item_id, back_to)]   # the pages open, the last on top: titles, and people ((role, backdrop))
    picks = ('fmt_title_next', 'fmt_title_kind', 'fmt_title_person', 'fmt_title_role')
    while stack:
        page = stack[-1]
        for p in picks:
            HOME.clearProperty(p)
        chosen = None
        if page[0] == 'person':
            name = person.show(addon_path, page[1], page[3], page[2], page[4])
        else:
            window = Title('script-freemytv-title.xml', addon_path, 'Default', '1080i')
            window.item_id, window.back_to = page[1], page[2]
            window.doModal()
            chosen, name, blurred = window.chosen, getattr(window, 'name', ''), window.blurred
            del window
        nxt, kind, who, role = (HOME.getProperty(p) for p in picks)
        for p in picks:
            HOME.clearProperty(p)
        if chosen:
            xbmc.executebuiltin('PlayMedia("%s",noresume)' % chosen)   # JellyCon asks about resuming
            return True
        if who:
            stack.append(('person', who, name + '  ·  Reparto', role, blurred))
        elif nxt and kind == 'Series':
            if series.show(addon_path, nxt):
                return True
        elif nxt:
            stack.append(('title', nxt, name))
        else:
            stack.pop()
    return False


def tab_name():
    """The tab the page was opened from (Home's focused tab), for its "‹ back to" line."""
    try:
        return HOME.getProperty('fmt_tab%d_name' % (int(HOME.getProperty('fmt_tabid') or 9001) - 9000))
    except ValueError:
        return ''
