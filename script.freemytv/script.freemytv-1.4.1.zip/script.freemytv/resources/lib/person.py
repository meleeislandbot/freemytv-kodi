"""A person's page (script-freemytv-person.xml), as the TV's PersonActivity: the photo, name, what they did, when and
where they were born, and their movies and shows in the library (Todo, Películas, Series), the newest first, as Home's
posters. OK on one opens its page (title.show keeps the way back).
"""
import calendar
import threading
import time
from urllib.parse import quote

import xbmc
import xbmcgui

import jellyfin
import settings

KINDS = (500, 501, 502, 503)
TYPES = ('Movie,Series', 'Movie', 'Series')   # Doblaje (503) is on or off with any of them: voice_ids
VOICE = ('(voice)', '(voz)', '(voice only)')
BACK = (9, 10, 92)
MONTHS = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre',
          'noviembre', 'diciembre')


def born(date, places):
    """'Nació el 1 de junio de 1996 en Kingston-upon-Thames…' (the server keeps a midnight in the person's zone)."""
    day = ''
    if date:
        try:
            t = time.gmtime(calendar.timegm(time.strptime(date[:19], '%Y-%m-%dT%H:%M:%S')) + 12 * 3600)   # noon: the right day
            day = '%d de %s de %d' % (t.tm_mday, MONTHS[t.tm_mon - 1], t.tm_year)
        except (ValueError, OverflowError):
            pass
    place = places[0] if places else ''
    if day:
        return 'Nació el ' + day + (' en ' + place if place else '')
    return 'Nació en ' + place if place else ''


class Person(xbmcgui.WindowXMLDialog):
    person_id = role = back_to = backdrop = ''
    asked = 0
    kind = 0        # Todo, Películas, Series
    dub = False     # Doblaje on: only their voice parts; off: those left out

    def onInit(self):
        o = jellyfin.call('/Users/{user}/Items/%s' % self.person_id)
        self.name = o.get('Name', '')
        self.setProperty('from', self.back_to)
        self.setProperty('backdrop', self.backdrop)
        self.setProperty('name', self.name)
        self.setProperty('initials', ''.join(w[0].upper() for w in self.name.split()[:2] if w))
        tag = o.get('ImageTags', {}).get('Primary')
        if tag:
            self.setProperty('photo', jellyfin.image(self.person_id, 'Primary', 480, tag))
        self.setProperty('about', '  ·  '.join(p for p in (self.role, born(o.get('PremiereDate'), o.get('ProductionLocations')))
                                                if p))
        self.voice = []
        threading.Thread(target=self.voice_ids, daemon=True).start()
        self.load()
        self.setFocusId(KINDS[0])

    def voice_ids(self):
        """The titles where their part is a voice ("Ian Lightfoot (voice)"): Doblaje shows once there's one, and the
        list without it leaves them out (asked for again)."""
        try:
            items = jellyfin.call('/Users/{user}/Items?PersonIds=%s&Recursive=true&IncludeItemTypes=Movie,Series'
                                  '&Fields=People&EnableImages=false&EnableUserData=false' % self.person_id).get('Items', [])
        except Exception as e:
            xbmc.log('Free My TV, person voices: %s' % e, xbmc.LOGWARNING)
            return
        self.voice = [o['Id'] for o in items if any(p.get('Id') == self.person_id and any(v in (p.get('Role') or '').lower()
                                                                                          for v in VOICE)
                                                    for p in o.get('People', []))]
        if self.voice:
            self.setProperty('voice', 'true')
            self.load()

    def load(self):
        """The person's titles of the kind, without their voice parts or only those (Doblaje), as JellyCon's items
        (Home's posters), the newest first, and how many there are."""
        self.setProperty('kind', str(self.kind))
        self.setProperty('dub', 'true' if self.dub else '')
        self.asked += 1   # a count still on its way for other choices is dropped
        query = ('/Users/{user}/Items?PersonIds=%s&Recursive=true&IncludeItemTypes=%s&SortBy=PremiereDate,SortName'
                 '&SortOrder=Descending' % (self.person_id, TYPES[self.kind]))
        if self.voice:
            query += ('&Ids=' if self.dub else '&ExcludeItemIds=') + ','.join(self.voice)
        self.setProperty('titles', 'plugin://plugin.video.jellycon/?url=' + quote(
            query.replace('{user}', '{userid}') + '&Limit=60' + settings.FIELDS, safe='/')
            + '&mode=GET_CONTENT&media_type=Playlist&sort=none')
        mine = self.asked
        self.setProperty('count', 'Contando…')

        def count():
            try:
                n = jellyfin.call(query + '&Limit=0&EnableImages=false&EnableUserData=false').get('TotalRecordCount', 0)
            except Exception as e:
                xbmc.log('Free My TV, person: %s' % e, xbmc.LOGWARNING)
                n = None
            if mine == self.asked:
                self.setProperty('count', '' if n is None else '1 título' if n == 1 else '%s títulos' % '{:,}'.format(n).replace(',', '.'))
        threading.Thread(target=count, daemon=True).start()

    def onClick(self, control):
        if control == KINDS[3]:   # Doblaje: on or off, with the kind as it is
            self.dub = not self.dub
            self.load()
        elif control in KINDS and KINDS.index(control) != self.kind:
            self.kind = KINDS.index(control)
            self.load()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


def show(addon_path, person_id, role, back_to, backdrop):
    """The person's page; the title chosen in it, if one (title.show opens it), as (id, kind)."""
    window = Person('script-freemytv-person.xml', addon_path, 'Default', '1080i')
    window.person_id, window.role, window.back_to, window.backdrop = person_id, role, back_to, backdrop
    window.doModal()
    name = getattr(window, 'name', '')
    del window
    return name
