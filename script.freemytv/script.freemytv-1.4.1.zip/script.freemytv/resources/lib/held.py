"""Holding OK on a TV's remote through HDMI-CEC (a TCL's): the TV sends no long press, only OK again every 0.3-0.4 s
while it's held, and Kodi takes each one as a new OK. So an OK within GAP of the last one is that press still held.
OK on Home's poster waits a moment for one (wait) before opening its page, and opens its quick actions (actions.py)
instead when it comes; the windows let the rest go by. Kodi hands a window the OKs that came while it was loading only
once it's loaded, so a window marks that moment as an OK too (mark)."""
import time

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
GAP = 0.6
WAIT = 0.5   # the first repeat comes 0.3-0.4 s after the press, its script some 0.1 s later


def mark():
    """A window has loaded: an OK queued while it loaded comes now, as if just after its press."""
    HOME.setProperty('fmt_ok_at', repr(time.time()))


def repeat():
    """Whether this OK is the last one, still held; it's noted either way."""
    now = time.time()
    try:
        last = float(HOME.getProperty('fmt_ok_at') or 0)
    except ValueError:
        last = 0
    HOME.setProperty('fmt_ok_at', repr(now))
    return 0 <= now - last < GAP


def wait():
    """OK on Home's poster: whether it's held (another OK comes within WAIT). A repeat that comes meanwhile runs the
    script again, which only notes it (fmt_held) and leaves."""
    if repeat():
        HOME.setProperty('fmt_held', '1')
        return False
    HOME.clearProperty('fmt_held')
    xbmc.Monitor().waitForAbort(WAIT)
    return bool(HOME.getProperty('fmt_held'))
