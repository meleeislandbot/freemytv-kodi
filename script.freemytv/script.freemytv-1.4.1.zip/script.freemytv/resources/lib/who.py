"""The Jellyfin user JellyCon is signed in as on this box (the profile in use: profiles.py), known without asking the
server, and the add-on's files that are that user's own: their tabs, their saved filters, the first tab's copy.
"""
import os
import re
from html import unescape

import xbmcgui
import xbmcvfs

HOME = xbmcgui.Window(10000)
PROPERTY = 'plugin.video.jellycon-user_name'   # JellyCon's HomeWindow puts its add-on id before its keys
SETTINGS = 'special://profile/addon_data/plugin.video.jellycon/settings.xml'


def name():
    """JellyCon's user: its window property (set at once when it changes), else its settings file."""
    n = HOME.getProperty(PROPERTY)
    if n:
        return n
    try:
        with open(xbmcvfs.translatePath(SETTINGS), encoding='utf-8') as f:
            m = re.search(r'<setting id="username"[^>]*>([^<]*)<', f.read())
    except OSError:
        return ''
    return unescape(m.group(1)) if m else ''


def own(path):
    """`path` (…/tabs.json) as the user's own (…/tabs-Eden.json), the one written."""
    user = re.sub(r'[^\w-]', '_', name())
    base, ext = os.path.splitext(path)
    return '%s-%s%s' % (base, user, ext) if user else path


def readable(path):
    """The user's own file, else the one every profile starts from (the box's from before profiles), as on the TV."""
    mine = own(path)
    return mine if os.path.exists(xbmcvfs.translatePath(mine)) else path
