"""A poster's quick actions (hold OK, as the TV's QuickActivity): play it, Watch Later, watched, More like this, an
episode's series and, last, JellyCon's own menu. JellyCon's menu replaces Kodi's context menu; the patch in
jellycon_fixes.py sends it here first while Home is open, and «Más opciones» opens JellyCon's after all.
"""
import xbmc
import xbmcgui

import held
import jellyfin
import later
import settings

HOME = xbmcgui.Window(10000)
GROUP, PANEL, ROWS = 98, 99, 100
ROW_H, TOP, BOTTOM = 76, 136, 24
BACK = (9, 10, 92)


def facts(o):
    """What it is · year · length · genres, as the TV's panel."""
    kind = o.get('Type')
    parts = ['Serie' if kind == 'Series' else 'Capítulo' if kind == 'Episode' else 'Película']
    if o.get('ProductionYear'):
        parts.append(str(o['ProductionYear']))
    minutes = int(o.get('RunTimeTicks') or 0) // 600000000
    if minutes:
        parts.append('%d h %d min' % divmod(minutes, 60) if minutes >= 60 else '%d min' % minutes)
    if o.get('Genres'):
        parts.append(' / '.join(o['Genres'][:2]))
    return '  ·  '.join(parts)


def rows(o):
    """[(action, label, hint, icon)] for the title."""
    kind, played = o.get('Type'), bool(o.get('UserData', {}).get('Played'))
    out = []
    if kind in ('Movie', 'Episode'):
        out.append(('play', 'Reproducir', '', 'play.png'))
    if kind == 'Movie':
        out.append(('later', 'Quitar de Ver más tarde' if o['Id'] in later.ids() else 'Ver más tarde', '', 'plus.png'))
    mark = ('Marcar como no vista' if played else 'Marcar como vista') if kind != 'Episode' else \
        ('Marcar como no visto' if played else 'Marcar como visto')
    out.append(('watched', mark, 'toda la serie' if kind == 'Series' else '', 'tick.png'))
    if kind in ('Movie', 'Series'):
        out.append(('similar', 'Más como esto', '', 'grid.png'))
    if kind == 'Episode' and o.get('SeriesId'):
        out.append(('series', 'Ir a la serie', 'temporadas y capítulos', 'lines.png'))
    out.append(('more', 'Más opciones', 'JellyCon', 'dots.png'))
    return out


class Actions(xbmcgui.WindowXMLDialog):
    item = None
    shown = ()
    chosen = None

    def onInit(self):
        self.setProperty('name', self.item.get('Name', ''))
        self.setProperty('facts', facts(self.item))
        items = []
        for _, label, hint, icon in self.shown:
            li = xbmcgui.ListItem(label, hint)
            li.setArt({'icon': 'freemytv/' + icon})
            items.append(li)
        control = self.getControl(ROWS)
        control.reset()
        control.addItems(items)
        control.setHeight(len(items) * ROW_H)
        height = TOP + len(items) * ROW_H + BOTTOM
        self.getControl(PANEL).setHeight(height)
        self.getControl(GROUP).setPosition(660, (1080 - height) // 2)
        self.setFocusId(ROWS)
        held.mark()

    def onClick(self, control):
        if held.repeat():   # the OK that opened this still held: not a choice
            return
        if control == ROWS:
            self.chosen = self.shown[self.getControl(ROWS).getSelectedPosition()][0]
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


def show(addon_path, item_id):
    o = jellyfin.call('/Users/{user}/Items/%s?Fields=Genres&EnableImages=false' % item_id)
    if not o:
        return
    window = Actions('script-freemytv-actions.xml', addon_path, 'Default', '1080i')
    window.item, window.shown = o, rows(o)
    window.doModal()
    chosen = window.chosen
    del window
    name = o.get('Name', '')
    if chosen == 'play':
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % jellyfin.play(item_id))   # JellyCon asks about resuming
    elif chosen == 'later':
        later.toggle(item_id, name)
    elif chosen == 'watched':
        want = not o.get('UserData', {}).get('Played')
        try:
            jellyfin.call('/Users/{user}/PlayedItems/%s' % item_id, 'POST' if want else 'DELETE')
            said = ('Marcado como visto: ' if want else 'Marcado como no visto: ') if o.get('Type') == 'Episode' else \
                ('Marcada como vista: ' if want else 'Marcada como no vista: ')
            xbmcgui.Dialog().notification('Free My TV', said + name, xbmcgui.NOTIFICATION_INFO, 3000)
            with settings.updating():
                settings.publish()   # Continue Watching, Next Up and the posters' marks change
        except Exception as e:
            xbmc.log('Free My TV, watched: %s' % e, xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Free My TV', 'No se pudo marcar: %s' % e, xbmcgui.NOTIFICATION_WARNING, 4000)
    elif chosen == 'similar':   # in Home's grid, as the TV's; Back brings the tab back
        settings.similar(item_id)
        xbmcgui.Dialog().notification('Más como esto', name, xbmcgui.NOTIFICATION_INFO, 3000, False)
    elif chosen == 'series':
        import series
        series.show(addon_path, o['SeriesId'])
    elif chosen == 'more':   # JellyCon's own menu, this time not sent here
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.jellycon/?mode=SHOW_MENU&item_id=%s&fmt_full=1)' % item_id)
