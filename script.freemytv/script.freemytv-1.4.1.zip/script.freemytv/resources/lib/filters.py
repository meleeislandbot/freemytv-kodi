"""Free My TV's filters for Kodi: a row of chips for each filter (kind, genre, era, rating, age, watched, country, woke, order)
in a list that scrolls up and down, and below, always in view, the titles they leave in the Jellyfin library and how
many. OK on a chip chooses it (genres take several), OK on a title opens or plays it. The window
(script-freemytv-filters.xml) is the Free My TV skin's: install.py writes its rows and chips, this fills them.

RunScript(script.freemytv,filters[,<slot>]): the funnel opens it as it was left; OK on a master tab (Películas, Series,
Documentales) opens it on that kind, the rest anew.
"""
import json
import os
import threading
import time
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcvfs

import jellyfin
import series
import settings
import who

HOME = xbmcgui.Window(10000)
ROWS, CHIPS = 10, 24   # what the window holds (install.py's FILTER_ROWS, FILTER_CHIPS)
RESULTS, RESET, SAVE, ROW = 300, 90, 91, 600
PAUSE = 0.3   # one question for a burst of presses
SHOWN = 150   # the titles shown by id: 33 characters each in the address
# A chip's colours, (unfocused, focused): chosen blue, the rest glass
CHOSEN, PLAIN = ('FF4AA8FF', 'FFBFE0FF'), ('1FFFFFFF', 'FFFFFFFF')
BACK = (9, 10, 92)

# The master collections, by tab name; the tab named like one opens the filters on it (install.py's MASTERS)
MASTERS = ('películas', 'series', 'documentales', 'cortos')
KINDS = ['Películas', 'Series', 'Documentales', 'Cortos']
TAB_KIND = {'películas': 'Películas', 'series': 'Series', 'documentales': 'Documentales'}
# shortcut: a fixed list of the library's genres, update it when the server's change (Jellyfin's /Genres takes 3 s)
# A genre is the title's main one: its only "genero:" tag (the server's Genres match any of a title's genres, so a comedy
# with a scene of terror came up under Terror)
GENRES = ['Acción', 'Animación', 'Anime', 'Aventura', 'Bélica', 'Ciencia ficción', 'Comedia', 'Crimen', 'Documental',
          'Drama', 'Familia', 'Fantasía', 'Historia', 'Misterio', 'Música', 'Romance', 'Suspense', 'Terror', 'Western']
# Documentales has categories instead (nearly every one's main genre is Documental): its "doccat:" tags, most titles first
DOC_CATS = [('Crimen e investigación', 'crimen-investigacion'), ('Sociedad y política', 'sociedad-politica'),
            ('Arte y cultura', 'arte-cultura'), ('Deporte y hazañas', 'deporte-hazanas'), ('Música', 'musica'),
            ('Biografías', 'biografias'), ('Historia y conflictos', 'historia-conflictos'),
            ('Naturaleza y medio ambiente', 'naturaleza-medioambiente'), ('Ciencia y tecnología', 'ciencia-tecnologia'),
            ('Viajes y gastronomía', 'viajes-gastronomia')]
ERAS = [('Cualquiera', None), ('Este año', 'year'), ('2020s', (2020, 2029)), ('2010s', (2010, 2019)),
        ('2000s', (2000, 2009)), ('90s', (1990, 1999)), ('80s', (1980, 1989)), ('70s', (1970, 1979)),
        ('Antes de 1970', (1800, 1969))]
RATINGS = [('Todas', 0), ('6 o más', 6), ('7 o más', 7), ('8 o más', 8)]
# The age ratings on the server, from several countries, by the youngest age each allows
# shortcut: only these; a rating not listed is left out while Edad is set, add it here when the server gets new ones
AGES = {r: age for age, ratings in (
    (0, 'APTA ES-APTA ES-ATP ES-A ES-Ai ES-TP TP G 0 0+ L TV-Y TV-G AA ALL'),
    (7, '6 ES-7 ES-7i PG ES-PG ES-pg TV-PG'),
    (10, '10'),
    (12, '12 12+ ES-12 K12 B'),
    (13, '13 ES-13 PG-13 PG13 ES-PG-13 ES-T U/A_13+'),
    (14, '14 14+ ES-14 TV-14'),
    (15, '15 B-15 MA_15+ Från_15_år M'),
    (16, '16 16+ ES-16 ES-+16 NC16'),
    (17, 'R ES-R'),
    (18, '18 +18 ES-18 19 NC-17 C TV-MA')) for r in (x.replace('_', ' ') for x in ratings.split())}
AGE = [('Todas', None), ('Todos los públicos', 0), ('Hasta 7', 7), ('Hasta 12', 12), ('Hasta 16', 16)]
WATCHED = [('Todas', ''), ('Sin ver', 'false'), ('Ya vistas', 'true')]
# The woke tags on the server ("woke:30-39"), by their lower bound; "Hasta 30" leaves out the known ones above 30 and
# keeps those with no figure (most of the library)
WOKE_TAGS = ['woke:0', 'woke:1-9', 'woke:10-19', 'woke:20-29', 'woke:30-39', 'woke:40', 'woke:41-49', 'woke:50-59',
             'woke:60-69', 'woke:70-79', 'woke:80-89', 'woke:90-99']
WOKE = [('Todo', None), ('Hasta 0', 0), ('Hasta 10', 10), ('Hasta 20', 20), ('Hasta 30', 30), ('Hasta 40', 40),
        ('Hasta 50', 50)]
ORDERS = [('Lanzamiento', '&SortBy=PremiereDate,SortName&SortOrder=Descending'),
          ('Nota', '&SortBy=CommunityRating,PremiereDate&SortOrder=Descending'),
          ('Nombre', '&SortBy=SortName&SortOrder=Ascending'),
          ('Recién añadidas', '&SortBy=DateCreated&SortOrder=Descending')]
DEFAULT = {'kind': 'Películas', 'genre': [], 'era': 'Cualquiera', 'rating': 'Todas', 'age': 'Todas', 'watched': 'Todas',
           'country': 'Cualquiera', 'woke': 'Todo', 'order': 'Lanzamiento'}


def later(seconds, function, *args):
    """A timer that doesn't hold the script open once the window is closed (Kodi waits for its threads before running
    it again, and the count can take seconds)."""
    timer = threading.Timer(seconds, function, args)
    timer.daemon = True
    timer.start()
    return timer


def remember():
    """The master collections' ids, in Home's fmt_masters (the service, at start and daily): asking the server for its
    collections takes some 3 s."""
    try:
        found = jellyfin.call('/Users/{user}/Items?IncludeItemTypes=BoxSet&Recursive=true&EnableImages=false'
                              '&EnableUserData=false').get('Items', [])
    except Exception as e:   # JellyCon signed out or the server away: the filters ask it then
        xbmc.log('Free My TV, filters: %s' % e, xbmc.LOGWARNING)
        return
    HOME.setProperty('fmt_masters', json.dumps({o['Name'].strip().lower(): o['Id'] for o in found
                                                if o.get('Name', '').strip().lower() in MASTERS}))
    return remember_kinds({o.get('Name', '').strip().lower(): o['Id'] for o in found})


def remember_kinds(names):
    """The Cortos tab's kinds, kept for settings.tab_what: the collections in "Tipos - Cortos" by name, then "Anime -
    Cortos". True when they changed (the tabs are published again)."""
    kinds = []
    try:
        if names.get('tipos - cortos'):
            kinds = [o['Id'] for o in jellyfin.call('/Users/{user}/Items?ParentId=%s&IncludeItemTypes=BoxSet&SortBy=SortName'
                                                    '&EnableImages=false&EnableUserData=false' % names['tipos - cortos'])
                     .get('Items', [])]
    except Exception as e:
        xbmc.log('Free My TV, kinds of shorts: %s' % e, xbmc.LOGWARNING)
        return False
    if names.get('anime - cortos'):
        kinds.append(names['anime - cortos'])
    if kinds == settings.short_kinds():
        return False
    import os
    import xbmcvfs
    path = xbmcvfs.translatePath(settings.KINDS)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(kinds, f)
    return True


def master(name):
    """The id of a master collection ('documentales'), or ''."""
    known = json.loads(HOME.getProperty('fmt_masters') or '{}')
    if not known.get(name):
        remember()
        known = json.loads(HOME.getProperty('fmt_masters') or '{}')
    return known.get(name, '')


def countries(kind):
    """[(name, collection id)] of the master's "Países" collections (Películas and Series have them)."""
    cached = HOME.getProperty('fmt_countries_' + kind)
    if cached:
        return json.loads(cached)
    out = []
    try:
        for group in jellyfin.call('/Users/{user}/Items?ParentId=%s&EnableImages=false&EnableUserData=false' % master(kind.lower()))['Items']:
            if group['Name'].lower().startswith('países'):
                out = [(o['Name'].rsplit(' - ', 1)[0], o['Id']) for o in jellyfin.call(
                    '/Users/{user}/Items?ParentId=%s&EnableImages=false&EnableUserData=false&SortBy=SortName' % group['Id'])['Items']]
    except Exception as e:
        xbmc.log('Free My TV, filters: %s' % e, xbmc.LOGWARNING)
    HOME.setProperty('fmt_countries_' + kind, json.dumps(out))
    return out


def query(state):
    """The Jellyfin items address for the filters ({user} for the user id), without paging or fields."""
    kind = state['kind']
    q = '/Users/{user}/Items?Recursive=true'
    country = dict(countries(kind)).get(state['country']) if kind in ('Películas', 'Series') else None
    if kind == 'Películas':
        q += '&IncludeItemTypes=Movie'
    elif kind == 'Series':
        q += '&IncludeItemTypes=Series'
    else:   # a master collection: its titles, of either kind
        q += '&IncludeItemTypes=Movie,Series&ParentId=' + master(kind.lower())
    if country:   # its country collection instead (Películas and Series only: one ParentId per question)
        q += '&ParentId=' + country
    if state['genre']:
        q += '&Tags=' + quote('|'.join(genre_tags(state)))
    era = dict(ERAS)[state['era']]
    if era:
        first, last = (int(time.strftime('%Y')),) * 2 if era == 'year' else era
        q += '&MinPremiereDate=%d-01-01T00:00:00Z&MaxPremiereDate=%d-12-31T23:59:59Z' % (first, last)
    if dict(RATINGS)[state['rating']]:
        q += '&MinCommunityRating=%d' % dict(RATINGS)[state['rating']]
    age = dict(AGE).get(state['age'])
    if age is not None:
        q += '&OfficialRatings=' + quote('|'.join(r for r, a in AGES.items() if a <= age))
    if dict(WATCHED)[state['watched']]:
        q += '&IsPlayed=' + dict(WATCHED)[state['watched']]
    return q + dict(ORDERS)[state['order']]   # woke: woke_out


LIGHT = '&EnableImages=false&EnableUserData=false&EnableTotalRecordCount=false'


def genre_tags(state):
    """The genres chosen as their tags: a title's main genre ("genero:Terror"), or in Documentales its category."""
    if state['kind'] == 'Documentales':
        return ['doccat:' + dict(DOC_CATS)[g] for g in state['genre'] if g in dict(DOC_CATS)]
    return ['genero:' + g for g in state['genre']]


def woke_out(state, q):
    """Woke up to N, which the server can't ask for (its Items take no ExcludeTags: it ignores them): (the ids of the
    first SHOWN titles without those known above N, how many there are), None while woke is any. Those above are few:
    asked for by their tags (the filters but the genre, which takes Tags too, then checked here) and counted out."""
    top = dict(WOKE)[state['woke']]
    if top is None:
        return None
    tags = [t for t in WOKE_TAGS if int(t[5:].split('-')[0]) > top]
    main = set(genre_tags(state))
    above = set(o['Id'] for o in jellyfin.call(query(dict(state, genre=[])) + '&Tags=' + quote('|'.join(tags))
                                                + '&Fields=Tags' + LIGHT).get('Items') or []
                if not main or main & set(o.get('Tags') or []))
    total = jellyfin.call(q + '&Limit=0&EnableImages=false&EnableUserData=false').get('TotalRecordCount', 0)
    ids, at = [], 0
    while len(ids) < SHOWN and at < total:   # the first ones, skipping those above (one at a time: together they're slower)
        page = jellyfin.call(q + '&StartIndex=%d&Limit=500' % at + LIGHT).get('Items') or []
        if not page:
            break
        ids += [o['Id'] for o in page if o['Id'] not in above]
        at += len(page)
    return ids[:SHOWN], total - len(above)


# MARK: - Filters saved as tabs («Guardar como pestaña»: the tab's what is 'filter:' and the filters' state)

SAVED = 'special://profile/addon_data/script.freemytv/filters.json'   # each one's address, as worked out last


def _saved():
    try:
        with open(xbmcvfs.translatePath(who.readable(SAVED)), encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _keep(known):
    path = xbmcvfs.translatePath(who.own(SAVED))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(known, f, ensure_ascii=False)


def work_out(what):
    """A saved filter's items address today, as the filters show it (with woke, its first SHOWN by id)."""
    state = dict(DEFAULT, **json.loads(what[len('filter:'):]))
    q = query(state)
    out = woke_out(state, q)
    return '/Users/{userid}/Items?Ids=' + (','.join(out[0]) or 'none') if out else q.replace('{user}', '{userid}') + '&Limit=200'


def saved_url(what):
    """The address publish gives the tab: the one worked out last (worked out now the first time)."""
    known = _saved()
    if what not in known:
        known[what] = work_out(what)
        _keep(known)
    return known[what]


def refresh_saved():
    """Each saved filter's tab worked out again (a new day: titles new on the server, Este año)."""
    known, fresh = _saved(), {}
    for what in [t['what'] for t in settings.load() if t['what'].startswith('filter:')]:
        try:
            fresh[what] = work_out(what)
        except Exception as e:   # the server away: as it was
            xbmc.log('Free My TV, saved filter: %s' % e, xbmc.LOGWARNING)
            if what in known:
                fresh[what] = known[what]
    _keep(fresh)


class Filters(xbmcgui.WindowXMLDialog):
    state = None
    chosen = None   # (path, kind, id) of a title picked, acted on once the window is closed
    timer = None

    def rows(self):
        """[(key, label, multi, options)] as shown now (countries only for Películas and Series)."""
        kind = self.state['kind']
        genre = ('genre', 'Categoría', True, ['Cualquiera'] + [n for n, _ in DOC_CATS]) if kind == 'Documentales' \
            else ('genre', 'Género', True, ['Cualquiera'] + GENRES)
        out = [('kind', 'Tipo', False, KINDS), genre,
               ('era', 'Época', False, [n for n, _ in ERAS]), ('rating', 'Nota', False, [n for n, _ in RATINGS]),
               ('age', 'Edad', False, [n for n, _ in AGE]), ('watched', 'Vistas', False, [n for n, _ in WATCHED])]
        if kind in ('Películas', 'Series'):
            out.append(('country', 'País', False, ['Cualquiera'] + [n for n, _ in countries(kind)]))
        out += [('woke', 'Woke', False, [n for n, _ in WOKE]), ('order', 'Orden', False, [n for n, _ in ORDERS])]
        return out[:ROWS]

    def onInit(self):
        self.fill()
        self.refresh()
        self.setFocusId(ROW + 1)

    def fill(self):
        """Every row's label and chips; then which are chosen."""
        self.shown = self.rows()
        for r in range(1, ROWS + 1):
            row = self.shown[r - 1] if r <= len(self.shown) else None
            self.setProperty('row%d' % r, row[1] if row else '')
            for i in range(CHIPS):
                self.setProperty('chip%d_%d' % (r, i), row[3][i] if row and i < len(row[3]) else '')
        self.marks()

    def marks(self):
        for r, (key, _, multi, options) in enumerate(self.shown, 1):
            value = self.state[key]
            for i, name in enumerate(options[:CHIPS]):
                on = (name in value or (name == 'Cualquiera' and not value)) if multi else name == value
                self.setProperty('bg%d_%d' % (r, i), CHOSEN[0] if on else PLAIN[0])
                self.setProperty('fg%d_%d' % (r, i), CHOSEN[1] if on else PLAIN[1])

    def onClick(self, control):
        if control == SAVE:
            self.save()
            return
        if control == RESET:
            self.state = dict(DEFAULT, kind=self.state['kind'], genre=[])
            self.marks()
            self.refresh()
            return
        r, i = divmod(control - 1000, 40)
        if not 1 <= r <= len(self.shown):
            return
        key, _, multi, options = self.shown[r - 1]
        if i >= len(options):
            return
        name = options[i]
        if multi:
            value = self.state[key]
            self.state[key] = [] if name == 'Cualquiera' else ([v for v in value if v != name] if name in value else value + [name])
        else:
            self.state[key] = name
        if key == 'kind':   # its rows change (País comes and goes, Documentales has categories) and belong to one kind
            self.state['country'] = 'Cualquiera'
            self.state['genre'] = []
            self.fill()
        else:
            self.marks()
        self.refresh()

    def save(self):
        """As a tab after the others, named by its genres and era (else its kind), and kept up to date there."""
        tabs = settings.load()
        if len(tabs) >= settings.SLOTS:
            xbmcgui.Dialog().ok('Guardar como pestaña', 'Caben %d pestañas: quita alguna primero.' % settings.SLOTS)
            return
        s = self.state
        named = ' '.join(s['genre'] + ([s['era']] if s['era'] != 'Cualquiera' else [])) or s['kind']
        name = xbmcgui.Dialog().input('Nombre de la pestaña', named).strip()
        if not name:
            return
        what = 'filter:' + json.dumps(s, ensure_ascii=False, sort_keys=True)
        with settings.updating():
            try:
                known = _saved()
                known[what] = work_out(what)
                _keep(known)
            except Exception as e:
                xbmc.log('Free My TV, saved filter: %s' % e, xbmc.LOGWARNING)
                xbmcgui.Dialog().notification('Free My TV', 'No se pudo guardar: %s' % e, xbmcgui.NOTIFICATION_WARNING, 4000)
                return
            settings.save(tabs + [{'name': name, 'what': what}])
            settings.publish()
        xbmcgui.Dialog().notification('Free My TV', '«%s» es ya la última pestaña' % name, xbmcgui.NOTIFICATION_INFO, 4000)

    def onAction(self, action):
        if action.getId() in BACK:
            if HOME.getProperty('fmt_filters_chosen'):   # a title picked: the results' onclick, then Back
                self.chosen = tuple(HOME.getProperty(p) for p in ('fmt_filters_chosen', 'fmt_filters_kind', 'fmt_filters_id'))
            self.close()

    def refresh(self):
        """The count and the titles after a pause."""
        HOME.setProperty('fmt_filters', json.dumps(self.state))
        if self.timer:
            self.timer.cancel()
        self.timer = later(PAUSE, self.lookup, json.dumps(self.state))

    def lookup(self, asked):
        if asked != json.dumps(self.state):
            return   # changed meanwhile: a newer one comes
        q = query(self.state)
        self.setProperty('count', 'Contando…')
        try:
            out = woke_out(self.state, q)
            if asked != json.dumps(self.state):
                return
            # shortcut: with woke, the first SHOWN by id (a longer address may not reach the server)
            url = '/Users/{userid}/Items?Ids=' + (','.join(out[0]) or 'none') if out \
                else q.replace('{user}', '{userid}') + '&Limit=200'
            HOME.setProperty('fmt_filters_path', 'plugin://plugin.video.jellycon/?url=' + quote(url + settings.FIELDS, safe='/')
                             + '&mode=GET_CONTENT&media_type=Playlist&sort=none')
            n = out[1] if out else \
                jellyfin.call(q + '&Limit=0&EnableImages=false&EnableUserData=false').get('TotalRecordCount', 0)
            if asked == json.dumps(self.state):
                self.setProperty('count', '1 título' if n == 1 else '%s títulos' % '{:,}'.format(n).replace(',', '.'))
        except Exception as e:
            xbmc.log('Free My TV, filters: %s' % e, xbmc.LOGWARNING)
            self.setProperty('count', '')


def show(addon_path, slot=''):
    state = dict(DEFAULT, **json.loads(HOME.getProperty('fmt_filters') or '{}'))
    if slot.isdigit():   # from a tab: its kind, the rest anew
        tabs = settings.load()
        name = tabs[int(slot) - 1]['name'].strip().lower() if 0 < int(slot) <= len(tabs) else ''
        state = dict(DEFAULT, genre=[], kind=TAB_KIND.get(name, 'Películas'))
    backdrop = settings.backdrop()
    while True:
        window = Filters('script-freemytv-filters.xml', addon_path, 'Default', '1080i')
        window.state = state
        window.setProperty('backdrop', backdrop)
        HOME.clearProperty('fmt_filters_chosen')
        window.doModal()
        chosen, state = window.chosen, window.state
        if window.timer:
            window.timer.cancel()
        del window
        for p in ('fmt_filters_chosen', 'fmt_filters_kind', 'fmt_filters_id'):
            HOME.clearProperty(p)
        if not chosen:
            break
        path, kind, item = chosen
        if kind == 'Series' and item:
            if series.show(addon_path, item):
                break   # an episode plays
            continue   # back to the filters, as they were
        if kind == 'Movie' and item:
            import title
            if title.show(addon_path, item, 'Filtros'):
                break
            continue
        xbmc.executebuiltin('PlayMedia("%s",noresume)' % path)   # JellyCon asks about resuming
        break
    HOME.clearProperty('fmt_filters_path')
